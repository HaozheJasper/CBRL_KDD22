import abc
import os
from collections import defaultdict
import pandas as pd
import numpy as np
import time
import pickle as pkl
from typing import Sequence
###### above are common imports for loaders
class LoaderTemplate(metaclass=abc.ABCMeta):
    @abc.abstractmethod # 要求子类实现
    def get_fnames(self):
        pass

    @abc.abstractmethod
    def get_slot_oracle_ratio(self, dayno, slot_no):
        pass

    @abc.abstractmethod
    def get_rev_scaler(self, dayno):
        pass

    @abc.abstractmethod
    def get_wkday_base(self):
        pass

    @abc.abstractmethod
    def how_many_days(self):
        pass

    @abc.abstractmethod
    def get_day_data(self, day_no):
        pass

    def get_day_slot_data(self, dayno, slotno):
        curday_df = self.get_day_data(dayno)  # self.bid_requests_list[self.cur_day]
        selector = curday_df.index[curday_df.time_slot == slotno]
        has_rq = len(selector) > 0

        if has_rq: return has_rq, curday_df.loc[selector]
        else: return False, None

    @abc.abstractmethod
    def get_rev_by_dayslot(self, dayno, slotno):
        """
        fetch slot rev by dayno,slotno
        """
        pass
    @abc.abstractmethod
    def get_cost_by_dayslot(self, dayno, slotno):
        """
        fetch slot cost by dayno,slotno
        """
        pass

    @abc.abstractmethod
    def randomize_days(self):
        pass

    @abc.abstractmethod
    def get_slot_len(self) -> int:
        pass

    @abc.abstractmethod
    def get_oracle_arr(self, *args) -> Sequence:
        pass

    def update_df(self, df, idx, base=0, drop=0., minimal=False):
        """
        add missing parts to data
        params: base, in some loading methods, test set starts from `base`, but indexes starts from 0.
        return: df, dataframe; wins, bool array
        """
        slot_len = self.get_slot_len()
        slot_in_hour = 60 // slot_len

        df.loc[:, 'time_slot'] = df['hr'] * slot_in_hour + df['min'] // slot_len  if slot_len<60 else df['hr'] // (slot_len // 60 ) # df['day_no'] * slot_in_day +

        if 'pppc' not in df.columns:
            df = df.rename(columns=dict(ppc='pppc'))
        if 'click' not in df.columns:
            df = df.rename(columns=dict(clk1='click'))

        # if 'value' not in df.columns:
        #     df['value'] = df.pppc * df.pctr * 1e3
        df.loc[:, 'rev'] = df.rev.fillna(0.)

        if not minimal:
            oracles = self.get_oracle_arr(df, idx)
            df['oracle'] = oracles

        no_k2 = 'k2' not in df.columns
        if no_k2 and not minimal:
            k2_arr = self.get_k2_arr(df, base=0) # loading from syn does not need base
            df.loc[:,'k2'] = k2_arr
        wins = None
        if not minimal:
            if 'value' not in df.columns:
                df['value'] = df.pppc * df.pctr * 1e3
            bids = df.value * df.k2
            wins = bids > df.costprice
            print('k2 win rate {}'.format(wins.sum() / len(bids)))
            df['loose'] = True
            df.loc[wins, 'loose'] = False
        if drop>0:
            df.drop(index=np.random.choice(df.index, size=round(drop*df.shape[0])), inplace=True)
        return df, wins

    def get_k2_arr(self, df, base=0): # only for syn data
        k2_arr = []
        shape_df = df[['day_no', 'time_slot']]
        for (dn, ts), group in shape_df.groupby(['day_no', 'time_slot'], sort=False):
            dn -= base # todo: fix 错位day_no是原始的idx，不是randomize后的
            # 必须保证train/test连续
            template = os.path.sep.join(self.file_paths[0].split(os.path.sep)[:-1])
            fname = template+'/{}.csv'.format(dn)
            ratio = self.slot_oracles[fname].get(ts, None)
            k2_arr.append(np.asarray([ratio] * group.shape[0]))

        return np.concatenate(k2_arr)

    @abc.abstractmethod
    def get_day_fname(self, dayno):
        pass

    def set_logger(self, logger):
        self.logger = logger