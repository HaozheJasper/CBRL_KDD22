from .base import *
import sys
sys.path.append('.')
class FileReader(LoaderTemplate):
    def __init__(self, folder, slot_len, cols, mode, train_days, train_files, is_cem=False, drop=0., data_ver='yewu_v3', setting='f', do_plot=False):
        self.data_folder = folder # ..v1/v9
        self.cols = cols
        self.drop = drop
        # if use_budget>0:
        #     budget_suffix = '_b{}'.format(use_budget)
        # else:
        #     budget_suffix = ''
        # if diverse_constraint:
        #     L_suffix = '_L'
        # else:
        #     L_suffix = ''
        # setting: 'f' 'bf' 'bL' 'bL1' 'L' 'b'
        # meta = pkl.load(open('../data/yewu-data/data_meta{}{}.pkl'.format(budget_suffix,L_suffix), 'rb'))
        if 'ood' in folder: folder = folder[-3:]
        is_syn = 'syn' in folder
        if is_syn:
            meta = pkl.load(open(os.path.join(folder, 'data_meta_v1_f.pkl'), 'rb'))
        else:
            folder += 'all'
            meta = pkl.load(open(os.path.join(folder, 'data_meta_v1_f.pkl'), 'rb'))


        self.meta = meta
        # self.policies = {k.split(os.path.sep)[-1].split('.')[0]: v for k,v in self.meta['policies'].items()}
        each_count = meta['each_count']
        if is_syn: self.file_paths = sorted(list(each_count.keys()))
        else: self.file_paths = list(each_count.keys())#glob(self.data_folder+'/*.csv') # list of csv file paths
        if is_cem and train_days>=len(self.file_paths):
            raise Exception('train days {} not smaller than existing days {}'.format(train_days, len(self.file_paths)))
        # tmp = pkl.load(open('../data/yewu-data/all0221/oracles_s{}{}{}.pkl'.format(slot_len, budget_suffix, L_suffix), 'rb'))
        num_slot_in_day = 24*60 // slot_len
        num_days = len(self.file_paths)
        self.istrain = mode=='train'
        self.train_days = train_days

        if train_files is None:
            self.file_paths = self.file_paths[:train_days] if mode=='train' else self.file_paths[train_days:]
        else:
            self.file_paths = train_files
            # self.slot_oracles = [tmp.get(x, None) for x in range(train_days*num_slot_in_day)]
            #[[tmp.get(x+k*num_slot_in_day, None) for x in range(num_slot_in_day)] for k in range(train_days)]
            # self.slot_oracles = [tmp.get(x, None) for x in range((num_days-train_days)*num_slot_in_day, num_days*num_slot_in_day)]
            # self.slot_oracles = [[tmp.get(x+k*num_slot_in_day, None) for x in range(num_slot_in_day)] for k in range(num_days-train_days, num_days)]
        fpaths = [x.split(os.path.sep)[-1].split('.')[0] for x in self.file_paths]
        policies = meta['policies'][setting]
        # mix_ratio:
        self.all_ratios = defaultdict(float)
        self.mix_ratios = dict()
        if is_syn:
            try:
                self.all_ratios = {day: pd['mix_ratio'] for day,pd in policies.items()}
            except:
                print('no mix_ratio key, skip..')
        if not is_syn: k2_policy = meta['policies']['online']
        data_folder = os.path.sep.join(self.file_paths[0].split(os.path.sep)[:-1])
        if do_plot:
            self.slot_oracles = defaultdict(dict)
        else:
            # tmp = pkl.load(
            #     open('../data/yewu-data/all0221/oracles_s{}{}{}.pkl'.format(slot_len, budget_suffix, L_suffix), 'rb'))
            dayid2soracle = {d.split(os.path.sep)[-1].split('.')[0]:p2f['slot_oracle']['ratios'] for d,p2f in policies.items()}
            self.slot_oracles = {data_folder+'/'+k+'.csv': v for k,v in dayid2soracle.items()} #[dayid2soracle[k] for k in fpaths]

        # tmp = meta['oracles']
        dayid2oracle = {k.split(os.path.sep)[-1].split('.')[0]: v['oracle']['ratio'] for k, v in policies.items()}
        self.oracle_ratios = [dayid2oracle[k] for k in fpaths]


        budgets = meta['budgets'][setting]
        self.budgets = {data_folder+'/'+k.split(os.path.sep)[-1]: v for k,v in budgets.items()}
        Ls = meta['Ls'][setting]
        self.Ls = {data_folder+'/'+k.split(os.path.sep)[-1]: v for k,v in Ls.items()}

         # {data_folder + '/' + k.split(os.path.sep)[-1]: v for k, v in policies.items()}
        if not is_syn:
            self.policies = dict()
            for k,v in policies.items():
                nbid = k2_policy[k]['nbid']
                k2 = k2_policy[k]['k2']
                v['k2'] = k2
                v['nbid'] = nbid
                self.policies[data_folder + '/' + k.split(os.path.sep)[-1]] = v
        else:
            self.policies = policies
        # self.backup_slot_oracles = [tmp[k] for k in self.file_paths]

        self.max_oracle_ratio = meta['max_ratio']
        self.min_oracle_ratio = meta['min_ratio']
        self.total_bids = meta['count']

        self.all_bid_requests = None  # df[['costprice','loose']].copy()
        # self.total_bids = df.shape[0]
        # pids, aders, users
        self.cat_sizes = [len(meta[k]) for k in self.cols]
        # tmp = meta['oracles']



        if len(self.file_paths)==0: raise Exception('folder might be incorrect: {}'.format(folder))
        self.slot_len_in_min = slot_len
        self.num_slot_in_day = 60 // slot_len * 24 if slot_len<60 else 24*60 // (slot_len)

        num_days = self.how_many_days()
        num_slots = num_days * self.num_slot_in_day
        self.oracle_rois = np.zeros(num_slots)

        self.revsum = None
        self.rev_scaler = 1.
        self.past_revsum = None
        # self.oracle_ratios = np.zeros(num_days)
        self.day_data, self.rev_by_slot, self.cost_by_slot = dict(), dict(), dict()
        self.ptr = -1
        # self.reset()
    def get_day_oracle(self, day):
        dayid = self.get_day_fname(day)
        # dayid = dayid.split(os.path.sep)[-1].split('.')[0]
        # policies = self.meta['policies']
        policies = self.policies
        so_rev = policies[dayid]['slot_oracle']['rev']
        go_rev = policies[dayid]['oracle']['rev']
        return max(so_rev, go_rev)

    def get_oracle_slot_stats(self, day, slotno):
        dayid = self.get_day_fname(day)
        policy = self.policies[dayid]['slot_oracle']
        rev,cost,nwin = policy['revlist'][slotno],policy['costlist'][slotno],policy['nwinlist'][slotno]
        return rev, cost, nwin

    def get_slot_len(self) -> int:
        return self.slot_len_in_min

    def get_oracle_arr(self, df, idx) -> Sequence:
        return self.oracle_ratios[idx]

    def preprocess(self, df, idx):
        print('prepro {}'.format(self.file_paths[self.ptr]))
        df, wins = self.update_df(df, idx, base=self.train_days if not self.istrain else 0, drop=self.drop if self.istrain else 0.)

        tmp = df[wins]
        dayno = idx
        uprois = np.zeros(self.num_slot_in_day)
        # for dayno, dgroup in tmp.groupby('day_no'): # only single day
        uprev, upcost = 0., 0.

        tmp_cost_by_slot, tmp_rev_by_slot = np.zeros(self.num_slot_in_day), np.zeros(self.num_slot_in_day)
        for k,group in tmp.groupby('time_slot'):
            # uprev += group.rev.sum()
            # upcost += group.costprice.sum()
            # uprois[k] = uprev / upcost * 1e3

            tmp_cost_by_slot[k] = group.costprice.sum()
            tmp_rev_by_slot[k] = group.rev.sum()

        self.rev_by_slot[dayno] = tmp_rev_by_slot
        self.cost_by_slot[dayno] = tmp_cost_by_slot
        # last_nonzero = 0
        # for idx,num in enumerate(uprois):
        #     if num!=0:
        #         last_nonzero = num
        #     else:
        #         uprois[idx] = last_nonzero
        #
        # self.oracle_rois[dayno*self.num_slot_in_day:(dayno+1)*self.num_slot_in_day] = uprois
        # get loose according to oracle
        print('prepro end')
        return df

    def get_rev_by_dayslot(self, dayno, slotno):
        """
        fetch slot rev by dayno,slotno
        """
        ans = 0.
        if dayno in self.rev_by_slot and self.num_slot_in_day > slotno >= 0:
            ans = self.rev_by_slot[dayno][slotno]
        return ans

    def get_day_rsum(self, dayno):
        return sum(self.rev_by_slot[dayno])

    def get_cost_by_dayslot(self, dayno, slotno):
        """
        fetch slot cost by dayno,slotno
        """
        ans = 0.
        if dayno in self.cost_by_slot and self.num_slot_in_day > slotno >= 0:
            ans = self.cost_by_slot[dayno][slotno]
        return ans*1e-3

    def get_slot_oracle_ratio(self, dayno, slot_no):
        fname = self.get_day_fname(dayno) # input normal day idx
        return self.slot_oracles[fname].get(slot_no, None)

    def get_meta(self):
        # load meta of dataset: max/min oracle, total bids, cat_sizes, costprice/loose histogram
        return self.oracle_ratios, self.cost_by_slot, self.max_oracle_ratio, self.min_oracle_ratio, self.all_bid_requests, self.cat_sizes

    def read_data(self, dayno):
        if dayno>=self.how_many_days():
            df = self.day_data[dayno-1]
        else:
            df = pd.read_csv(self.file_paths[dayno]) # 是一个trick，在最后一天不能读下一天，于是用当天冒充了，反正不会真的用到
            df = self.preprocess(df, dayno)
        self.day_data[dayno] = df
        tmp = self.revsum
        self.revsum = df.rev[~df.loose].sum()
        if self.past_revsum is not None:
            self.rev_scaler *= self.past_revsum / self.revsum # reciprocal
        self.past_revsum = tmp

    def get_day_data(self, day_no, drop=None):
        if day_no not in self.day_data:
            # print('removing rank-{}, reading rank-{}'.format(self.ptr, day_no))
            self.ptr = day_no
            self.read_data(day_no)
            # get mix ratio
            fpath = self.file_paths[day_no]
            mix_ratio = self.all_ratios[fpath]
            self.mix_ratios[day_no] = mix_ratio

        if drop in self.day_data:
            self.day_data.pop(drop)
            self.rev_by_slot.pop(drop)
            self.cost_by_slot.pop(drop)

        return self.day_data[day_no]

    def get_fnames(self):
        return self.file_paths

    def get_day_fname(self, dayno):
        return self.file_paths[dayno]

    def get_rev_scaler(self, day_no):
        # return self.oracle_revs[self.get_day_fname(day_no)]
        return 1./self.get_day_oracle(day_no)

    def randomize_days(self):
        day_idxes = np.arange(self.how_many_days())
        day_idxes = np.random.permutation(day_idxes)
        self.day_idxes = day_idxes

        self.file_paths = [self.file_paths[i] for i in day_idxes]
        self.oracle_ratios = [self.oracle_ratios[i] for i in day_idxes]
        # self.slot_oracles = [self.slot_oracles[i] for i in day_idxes]
        print('randomized days {}'.format(self.file_paths))

    # def reset(self):
    #     self.ptr = 0
    #     self.read_data()

    def get_wkday_base(self):
        return 0 # self.day_data[0].wkday.iloc[0]

    def how_many_days(self):
        return len(self.file_paths)