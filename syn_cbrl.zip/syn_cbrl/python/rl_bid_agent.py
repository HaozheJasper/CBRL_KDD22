import sys,os
import gym
sys.path.append(os.getcwd()+'/src')
import auction_simulator
from auction_simulator import Observation
from collections.abc import Sequence
# import numexpr as ne
# from dask.multiprocessing import get
# import random
# import torch
# import numpy as np

from sac import SAC
import numpy as np
import pandas as pd
import time
from torch.utils.tensorboard import SummaryWriter
import torch
from torch.optim import lr_scheduler
import logging
# from censoredlearning import HistModel
from runner_utils import make_parser, report, main, get_logger, train_or_test, Checkpointer, interfaces, count_params
from networks import tokenize_continuous_values
import pickle as pkl
import random

        # if self.test: return False
        # num_wks = self.day_cnt // 7
        # idx = num_wks % 5  # 4 for train 1 for eval
        # if idx == 4:
        #     return False
        # else:
        #     return True
# class StatePreserver():
#     def update(self, current_obs):
#         if current_obs['hour'] != self.cur_hour and current_obs['weekday'] == self.cur_day:
#             # self._update_step()  # obtain hour-level state
#             self.t_step += 1
#             self.cur_hour = current_obs['hour']
#
#         elif current_obs['weekday'] != self.cur_day:
#             # self.rev_e = self.daily_return
#             self.cur_day = current_obs['weekday']
#             self.cur_hour = current_obs['hour']
#
#         if k2_info is not None: self.set_day(self.day_cnt + 1)

        # agent: batch_step(rewards); batch_act(); stage(); rollback();
def handle_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    logging.getLogger('default').error("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))  # 重点

sys.excepthook = handle_exception  # 重点


class BidAgent(interfaces):

    def get_logger_writer(self):
        self.logger = get_logger(self.output_dir)
        self.writer = SummaryWriter(self.output_dir)

    def _load_config(self, cfg):
        """
        Parse the config.cfg file
        """
        # cfg = configparser.ConfigParser(allow_no_value=True)
        # # env_dir = os.path.dirname(__file__)
        # self.cfg_path = cfg_path = './config.cfg'
        # print('read agent config from {}'.format(cfg_path))
        # cfg.read(cfg_path)
        self.cfg = cfg
        # import ipdb; ipdb.set_trace()
        self.budget = eval(cfg['agent']['budget'])
        self.target_value = int(cfg['agent']['target_value'])
        self.T = int(cfg['rl_agent']['T'])  # T number of timesteps
        self.STATE_SIZE = 12 #int(cfg['rl_agent']['STATE_SIZE'])
        self.ACTION_SIZE = int(cfg['rl_agent']['ACTION_SIZE'])
        self.train_episodes_num = int(cfg['rl_agent']['train_num'])
        self.eval_freq = int(cfg['rl_agent']['eval_freq'])
        self.include_loosing = eval(cfg['data']['include_loosing'])
        self.use_syn = cfg['data']['use_syn']
        self.gamma = eval(cfg['rl_agent']['gamma'])
        self.discount = eval(cfg['rl_agent']['discount'])
        self.agent_type = cfg['rl_agent']['agent_type']
        self.ablation = eval(cfg['rl_agent']['ablation'])
        self.action_start = eval(self.cfg['rl_agent']['action_lo'])
        self.action_end = eval(self.cfg['rl_agent']['action_hi'])
        self.action_step = eval(self.cfg['rl_agent']['action_num'])
        self.max_loss_save = eval(self.cfg['rl_agent']['max_loss'])
        # self.init_price = int(cfg['agent']['init_price'])
        # self.expected_win = int(cfg['agent']['expected_win'])
        # self.memo = 'roi'

        self.wkday_feature = eval(cfg['rl_agent']['wkday_feat'])
        self.future_costs_feature = eval(cfg['rl_agent']['future_costs'])

        self.restore_dir = cfg['rl_agent']['restore_dir']
        self.restore_epoch = cfg['rl_agent']['restore_epoch']
        use_history = eval(cfg['rl_agent']['use_history'])
        is_ep = eval(cfg['data']['gamma_nepoch'])>1 and eval(cfg['rl_agent']['rewardtype'])==6
        resume = eval(cfg['rl_agent']['resume'])
        self.is_ep = is_ep and use_history and resume

        self.slot_len_in_min = eval(cfg['data']['slot_len'])
        self.num_slot_in_period = eval(cfg['data']['period_len'])
        self.nslot_in_day = 24*60//self.slot_len_in_min

        self.test_incremental = eval(cfg['data']['test_inc'])
        self.ratio_update_type = eval(cfg['rl_agent']['ratio_update_type'])
        self.tri_player = eval(cfg['rl_agent']['tri_player'])
        self.learn_limits = eval(cfg['rl_agent']['learn_limits']) and not self.tri_player # todo: separater learn limits with tri-player

        self.discrete_action = eval(cfg['rl_agent']['discrete_action'])
        self.encoder_type = cfg['rl_agent']['encoder_type']

    def validate_action_space(self, env):
        max_oracle_ratio = env.max_oracle_ratio
        min_oracle_ratio = env.min_oracle_ratio
        min_action, max_action = self.action_start, self.action_end
        min_ratio,max_ratio = min_action, max_action
        span = max_ratio - min_ratio
        min_margin = min_oracle_ratio - min_ratio # should be positive
        max_margin = max_ratio - max_oracle_ratio # positive
        info = '{} - oracle ratio margin: min={}%({}vs{}),max={}%({}vs{})'.format(env.spec.id,
                                                                                 round(min_margin/span*100, 2),
                                                                                 min_ratio, min_oracle_ratio,
                                                                                 round(max_margin/span*100, 2),
                                                                                 max_ratio, max_oracle_ratio)
        if min_margin>=0 and max_margin>0:
            self.logger.info(info)
        else:
            raise Exception(info)

    def _get_state_size(self):
        pass
    def save_and_learn(self, env, can_train=False):
        pass
    def act(self, env, current_obs):
        pass
    # def batch_act(self):
    #     pass
    def eval(self):
        self.agent.eval()

    def set_train(self):
        self.agent.set_train()

    def get_multiplier(self):
        return self.agent.get_multiplier()

    def get_limit_parameter(self, detach=True):
        return self.agent.get_limit_parameter(detach=detach)

    def __init__(self, cfg, state_size, full_state_size=None, cat_sizes=tuple(), test_mode=False, envname='yewu', writer=None):
        self.test = test_mode
        self.envname = envname
        # self.BETA = self._get_action_space()  # [-0.08, -0.03, -0.01, 0, 0.01, 0.03, 0.08]
        self._load_config(cfg)
        self.BETA = self._get_action_space()  # [-0.08, -0.03, -0.01, 0, 0.01, 0.03, 0.08]
        buffertype = eval(cfg['rl_agent']['buffertype'])
        self.reward_type = eval(cfg['rl_agent']['rewardtype'])
        self.multi_timescale = self.reward_type==3 # use lagrangian

        self.penalty_scale = self.init_penalty_scale = float(cfg['hypers']['penalty'])  # float(cfg['agent']['penalty'])
        self.simplified = eval(cfg['rl_agent']['simplified'])
        self.model_name = '{}_slot({})_s({})_a({})'.format(self._get_model_name(), eval(cfg['data']['slot_len']),
                                                           state_size, len(self.BETA))

        self.output_dir = self.cfg['data'][
                              'output_dir'] + '/' + '{}_{}_{}_agent({})_dis({})_gamma({})_actiontype({})_reward({})_penalty({})_slot({})_wloose({})_syn({})_buffer({})'.format(
            time.strftime('%y%m%d%H%M%S', time.localtime()),
            self.model_name,
            self.envname,
            self.agent_type,
            self.discount,
            self.gamma,
            self.ratio_update_type,
            self.reward_type,
            self.penalty_scale,
            self.slot_len_in_min,
            self.include_loosing,
            self.use_syn,
            buffertype,

        )
        os.makedirs(self.output_dir, exist_ok=True)
        self.get_logger_writer()
        if not self.test:
            self.logger.info('output to {}, train for {}'.format(self.output_dir, self.train_episodes_num))
            self.logger.info('using ep checkpointer: {}'.format(self.is_ep))
            self.cfg.write(open(os.path.join(self.output_dir, 'config.cfg'), 'w'))
            # import shutil
            # # src_file = cfg_path
            # target_folder = self.output_dir
            # shutil.copy(self.cfg_path, target_folder)




        # Control parameter used to scale bid price

        # self.BETA = self.BETA + [10*x for x in self.BETA]
        self.eps_start = 1.0
        self.eps_end = 0.05
        self.anneal = 0.00005

        # DQN Network to learn Q function
        replay_scheme = cfg['rl_agent']['replay_scheme']
        if self.agent_type=='dqn':
            self.agent = DQN(cfg, state_size=state_size, action_size=len(self.BETA), seed=eval(cfg['data']['seed']), cat_sizes=cat_sizes,
                         use_wkday_feat=self.wkday_feature, buffertype=buffertype, replay_scheme=replay_scheme,
                         discount=self.discount, simplified=self.simplified)
        elif self.agent_type =='ddpg':
            action_bound = (self.action_start, self.action_end)

            self.agent = DDPG(cfg, state_size=state_size, action_size=1, seed=eval(cfg['data']['seed']),
                              action_bound=action_bound,
                              buffertype=buffertype, replay_scheme=replay_scheme,
                              discount=self.discount, simplified=self.simplified)
            self.logger.info('ddpg lr is {}, train freq is {}'.format(self.agent.lr, self.agent.train_freq))

        else:
            action_bound = (self.action_start, self.action_end)
            if self.encoder_type == 'transformer3':
                clsname = TransSAC2
            else:
                clsname = SAC if not self.discrete_action else DiscreteSAC
            self.agent = clsname(cfg, state_size=state_size, full_state_size=full_state_size, action_size=1, seed=eval(cfg['data']['seed']), action_bound=action_bound,
                             buffertype=buffertype, replay_scheme=replay_scheme,
                         discount=self.discount, simplified=self.simplified)
            self.logger.info('sac lr is {}, train freq is {}'.format(self.agent.lr, self.agent.train_freq))
        self.logger.info('{} net {}'.format('='*10, '='*10))
        total_count = 0
        report_str = ''
        for net in self.agent.networks:
            self.logger.info(str(net))
            pcount = count_params(net)
            report_str += 'name={}, number_params={}\n'.format(type(net), pcount)
            total_count += pcount
        report_str += 'total={}'.format(total_count)
        self.logger.info('{} params {}'.format('=' * 10, '=' * 10))
        self.logger.info(report_str)


        self.oracle_agent = None

        self.logger.info('torch seed {}'.format(self.agent.torch_seed))
        self.buffertype = buffertype

        self.scheduler = self.agent.scheduler

        # if self.agent_type=='sac':
        #
        # else:
        #     self.scheduler = lr_scheduler.MultiStepLR(self.agent.optimizer, milestones=[4000, 8000, 12000], gamma=0.5)
        # self.dqn_agent.save(self.output_dir)
        # import ipdb; ipdb.set_trace()
        # Reward Network to reward function
        # self.reward_net = RewardNet(state_action_size=self.STATE_SIZE + 1, reward_size=1, seed=0)
        self.dqn_state = None
        self.dqn_action = 3  # no scaling
        self.dqn_reward = 0
        # Reward-Dictionary
        # self.reward_dict = {}
        # self.daily_seen_sa = []
        # self.daily_return = 0
        self.total_win = []
        self.total_rev = []
        self.total_cost = []
        self.total_bids = []
        self.total_win2 = []
        self.total_rev2 = []
        self.total_cost2 = []
        self.total_reward = [] # Fake
        self.total_reward_rw = [] # real

        # self.day_no = 0

        self.qnet_loss, self.q_amp = None, None
        # self._reset_day()

        # self.return_meter = meter.AverageValueMeter()
        # self.penalty_meter = meter.AverageValueMeter()
        # self.step_time_meter = meter.AverageValueMeter()
        # # self.reward_meter = LimitedMeter(1000)
        # self.reward_meter = meter.AverageValueMeter()
        # self.avg_scale_records = []

        # self.writer = SummaryWriter()
        self.writer = SummaryWriter(self.output_dir)
        self.checkpointer = Checkpointer(is_ep=self.is_ep, old_yewu='Yewu' in self.envname)
        self.model_step = 0
        self.global_step = 0

        dat = ['envname', 'actiontype', 'slotno', 'dayno', 'ratio', 'overall_roi', 'original_reward', 'normalized_reward', 'refratio',
               'step_winrate', 'step_rev', 'step_cost', 'step_roi', 'rev', 'cost', 'win', 'nbid'] + ['roi', 'roi-penalty', 'step_rev', 'rev-reward','exp-penalty']
        if eval(self.cfg['rl_agent']['rewardtype'])==3:
            dat.append('oracle_roi')
        # [original_r, roi, min(roi-1,0)*self.penalty_scale, step_rev, step_rev*self.reward_scale]
        pd.DataFrame([dat]).to_csv(os.path.join(self.output_dir, '{}_actions.csv'.format(self._get_model_name())),
                                   header=False,
                                   index=False, mode='w')

        self.init_lambda = eval(
            self.cfg['rl_agent']['init_lambda'])
        self.last_ratio = self.init_lambda

        self.eps = 1.
        # self.save(None, None)
        # self.restore_dir = self.output_dir
        # self.restore()

        # self.pv_value = None
    def _get_action_space_independent(self):
        start = self.action_start #eval(self.cfg['rl_agent']['action_lo'])
        end = self.action_end # eval(self.cfg['rl_agent']['action_hi'])
        num_step = self.action_step # eval(self.cfg['rl_agent']['action_num'])
        step_size = (end-start)/num_step

        tmp = np.arange(start, end+step_size, step_size)
        return tmp

    def _get_action_space_correlated(self):
        return [-0.7,-0.5,-0.2,0.,0.2,0.5,0.7]

    def _get_action_space(self):
        if self.ratio_update_type==0:
            return self._get_action_space_independent()
        else: return self._get_action_space_correlated()

    def check_save(self):
        return self.checkpointer.check_save()
        # if self.qnet_loss is None or self.qnet_loss<self.max_loss_save: return True
        # else:
        #     self.logger.info(r"loss too large, don't save, {}".format(self.qnet_loss))
        #     return False

    def save(self, epoch, reward_scaler):
        self.agent.save(self.output_dir, '{}_{}'.format(self._get_model_name(), epoch), reward_scaler)
        # self.reward_net.save(self.output_dir)
    def load(self, epoch):
        print('scaler', self.agent.restore(self.output_dir, '{}_{}'.format(self._get_model_name(), epoch)))

    def clear_buffer(self):
        [x.clear() for x in self.agent.buffer.memory]

    def restore(self):
        return self.agent.restore(self.restore_dir, '{}_{}'.format(self._get_model_name(), self.restore_epoch))
        # self.reward_net.restore(self.restore_dir)
        # print('model dumped to {}'.format(self.output_dir))

    # def log(self, path, dat):
    #     pd.DataFrame([dat]).to_csv(os.path.join(path, '{}_actions.csv'.format(self._get_model_name())), header=False, index=False, mode='a')

    def set_period_exploration_factor(self, factor):
        self.eps = factor
        # print('exploration factor {} for next period'.format(self.eps))

    def set_exploration_factor(self, day_no):
        progress = (day_no % self.eval_freq) / self.eval_freq
        self.eps = self.eps_start * (1 - progress)
        print('exploration factor {} for next day {}'.format(self.eps, day_no))

    def update_total_stats(self, ): # todo use realworld
        self.total_win.append(self.wins_e_rw)
        self.total_rev.append(self.rev_e_rw)
        self.total_cost.append(self.cost_e_rw)
        self.total_bids.append(self.bids_e)
        self.total_win2.append(self.wins_e)
        self.total_rev2.append(self.rev_e)
        self.total_cost2.append(self.cost_e)
        self.total_reward.append(self.reward_e)
        self.total_reward_rw.append(self.reward_e_rw)

        self.logger.debug('compare fake/real:{}vs{},{}vs{},{}vs{}'.format(self.wins_e, self.wins_e_rw, self.rev_e, self.rev_e_rw, self.cost_e, self.cost_e_rw))
        # _, rev, cost, roi, win, wr = compute('', self.rev_e_rw, self.cost_e_rw, self.wins_e_rw, self.bids_e)
        # if writer is not None:
        #     # writer = self.writer
        #     _, rev, cost, roi, win, wr = compute('', self.rev_e_rw, self.cost_e_rw, self.wins_e_rw, self.bids_e)
        #     writer.add_scalar('{}/wins'.format(prefix), win, self.day_no)
        #     writer.add_scalar('{}/revs'.format(prefix), rev, self.day_no)
        #     writer.add_scalar('{}/costs'.format(prefix), cost, self.day_no)
        #     writer.add_scalar('{}/roi'.format(prefix), roi, self.day_no)
        #     writer.add_scalar('{}/winrate'.format(prefix), wr, self.day_no)
        #     _, rev, cost, roi, win, wr = compute('', self.rev_e, self.cost_e, self.wins_e, self.bids_e)
        #     writer.add_scalar('{}/wins_fake'.format(prefix), win, self.day_no)
        #     writer.add_scalar('{}/revs_fake'.format(prefix), rev, self.day_no)
        #     writer.add_scalar('{}/costs_fake'.format(prefix), cost, self.day_no)
        #     writer.add_scalar('{}/roi_fake'.format(prefix), roi, self.day_no)
        #     writer.add_scalar('{}/winrate_fake'.format(prefix), wr, self.day_no)

            # print('written')

    def set_ratio(self, env, ratio):
        pass

    # def batch_step(self, env, batch_fake_rew, batch_fake_cost, batch_fake_win, batch_nbids, batch_rew_t, batch_cost_t, batch_win_t, do_train=False):
    #
    #     self._update_reward_cost_slot(batch_fake_rew, batch_fake_cost, batch_fake_win, batch_nbids, batch_rew_t, batch_cost_t, batch_win_t)
    #     # print('agent', self.wins_e, self.bids_e)
    #     # if env.past_hour_ends(): # each step will be a slot step
    #     self.t_step = env.get_current_slot()
    #     self.daily_return += self.rev_t
    #     self.return_meter.add(self.rev_t)
    #
    #     dayno = (env.slot_no - 1) // env.num_slot_in_day
    #     # if dayno>env.bid_requests.day_no.max():
    #     #     print()
    #     # ref_ratio = env.bid_requests[env.bid_requests.day_no==dayno].oracle.iloc[0]
    #     ref_ratio = env.oracle_ratios[dayno]
    #     # try:
    #     #
    #     # except:
    #     #     print()
    #     # self.log(self.output_dir,
    #     #          [env.spec.id, 'exp' if self.during_exp() else 'act', env.slot_no - 1, dayno,
    #     #           self.wins_e / self.bids_e,
    #     #           self.ratio,
    #     #           ref_ratio,
    #     #           self.rev_e / self.cost_e, self.rev_e, self.cost_e, self.wins_e, self.bids_e])  # todo 用agent自己以为的
    #
    #     if env.past_day_ends() and not self.during_exp():  # at the end of a day, clear all the states
    #         # import ipdb; ipdb.set_trace()
    #         # print(self.t_step, self.daily_return, env.past_slot_wkday)
    #         self.log_episode_perf(env.past_slot_day, env.get_k2_info())
    #         self.logger.debug('loss stats: q_amp={}, qnet_loss={}'.format(self.q_amp, self.qnet_loss))
    #         self.set_day(env.get_day())
    #         self.update_total_stats()
    #         # self._reset_epfisode()
    #
    #         self.logger.info('day {} over: average reward scale, {}; average penalty, {}'.format(env.get_day(), self.return_meter.value()[0],
    #               self.penalty_meter.value()[0]))
    #
    #         if env.past_week_ends():
    #             avg_rew_scale = self.return_meter.value()[0]
    #             self.logger.info('week over: average reward scale, {}, average penalty, {} '.format(avg_rew_scale,
    #                   self.penalty_meter.value()[0]))
    #             if len(self.avg_scale_records) > 0:
    #                 factor = avg_rew_scale / self.avg_scale_records[-1]
    #                 self.penalty_scale = self.penalty_scale * factor
    #                 self.logger.info('penalty factor {}'.format(factor))
    #             self.avg_scale_records.append(avg_rew_scale)
    #             self.return_meter.reset()
    #             self.penalty_meter.reset()
    #
    #     step_reward = self.save_and_learn(env, can_train=do_train) # fake
    #     if not self.during_exp():
    #         self.reward_e += step_reward
    #         if env.use_syn():
    #             step_rw = self.compute_reward(env.get_past_slot_day(), env.get_current_slot(), real=True, env=env)
    #             self.reward_e_rw += step_rw
    #         else:
    #             self.reward_e_rw += step_reward
    #
    #     dat = [env.spec.id, 'exp' if self.during_exp() else 'act',
    #            env.get_current_slot(),
    #            dayno,
    #            self.ratio,
    #            self.rev_e / self.cost_e,
    #            step_reward,
    #            ref_ratio,
    #            self.wins_e / self.bids_e,
    #            self.rev_e, self.cost_e, self.wins_e, self.bids_e]
    #     # dat = [envname, actiontype, slotno, dayno, ratio, roi, reward, refratio, winrate, rev, cost, win, nbid]
    #     pd.DataFrame([dat]).to_csv(os.path.join(self.output_dir, '{}_actions.csv'.format(self._get_model_name())),
    #                                header=False,
    #                                index=False, mode='a')
    #
    #     # if self.is_train() and env.past_week_ends():
    #     #     self.set_exploration_factor(env.cur_day)
    #     self._reset_slot() # always do this for each slot
    #     if env.past_day_ends(): self._reset_day()



class BaseAgent_discrete(BidAgent):
    def _get_model_name(self):
        return 'BaseAgent'

    def set_base_lambda(self, lamb):
        self.slot_lambda = lamb

    def _pv_step(self, env, current_obs):
        pass

    def update_buffer(self, tup, priority=None):
        # if self.buffertype==4: self.update_buffer_per(tup, priority=priority)
        # else: self.update_buffer_normal(tup, priority=priority)
        # self.update_buffer_per(tup, priority=priority)
        self.agent.update_memory2(tup, priority)

    def clear_buffer(self):
        self.agent.clear_buffer()

    def update_buffer_normal(self, tup, priority=None):
        last_obs, action, r, obs, episode_done = tup
        self.agent.update_memory(None, last_obs, action, r, obs, episode_done)

    def update_buffer_per(self, tup, priority=None):
        self.agent.update_memory2(tup, priority)

    def get_bid_ratio(self, last_ratio, action):
        if self.discrete_action:
            return self.agent.normalizer.token2ratio(action.item(), use_mulaw=False)
        else: return action


    def dayover_logging(self):
        self.logger.debug('step {} loss stats: q_amp={}, qnet_loss={}'.format(self.model_step, self.q_amp, self.qnet_loss))
        self.logger.debug('init value: {}'.format(self.agent.state_normalizer.init_value))
        # self.set_day(env.get_day())
        # self.update_total_stats()
    def checkpointer_add_acc(self, item):
        self.checkpointer.add_acc_item(item)

    def get_lr(self):
        return self.agent.get_lr()

    def scheduler_step(self):
        if self.scheduler is not None:
            if isinstance(self.scheduler, Sequence):
                [sched.step() for sched in self.scheduler]
            else: self.scheduler.step()

    def postprocess_reward(self, obs, action, nobs, rew):
        if rew is None: rew = 0
        rew = self.agent.postprocess_reward(obs, action, nobs, rew)

        return rew

    def learn(self, train_model=True, train_other=True, iter_multiplier=1):
        ret = dict()
        if train_model:
            tmp = self.agent.train_agent(iter_multiplier=iter_multiplier)
            ret.update(tmp)

            if len(ret)>0:
            # qnet_loss, amp, qmin, qmax, qstd = ret['qnet']
                self.qnet_loss = ret['qnet_loss']
                self.q_amp = ret['qvalue_max']
                self.checkpointer.add_loss_item(self.qnet_loss)
                for k in ret.keys():
                    self.writer.add_scalar('train_stats/{}'.format(k), ret[k], self.model_step)

                self.scheduler_step()
                self.model_step += 1
                # print('model step', self.model_step)

        ret = dict()

        self.global_step += 1



    def batch_act(self, obs, is_oracle=False): # batch act before slot_step, not incremented
        if not is_oracle: agent = self.agent
        else: agent = self.oracle_agent
        if self.ratio_update_type==1:
            last_ratio = obs[1]
            allowed_idxes = [last_ratio+x>0 for x in self._get_action_space()]
        else: allowed_idxes = None

        action_next_slot = agent.act(obs, eps=self.eps if self.during_exp() else 1., is_deterministic=not self.during_exp(),
                                          allowed=allowed_idxes) # state is converted in act()
        if is_oracle and self.discrete_action: # oracle output is ratio not token, so we turn ratio into token
            tmp = self.agent.normalizer.convert_actions(action_next_slot)
            action_next_slot = tokenize_continuous_values(tmp, use_mulaw=False)
        elif not is_oracle:
            action_next_slot = action_next_slot.item()
        return action_next_slot

    def batch_act_both(self, obs):
        """
        return: dict if use_oracle else scaler
        """
        return self.batch_act(obs)

    def _get_state_size(self):
        base_len = 10 if not self.simplified else 3
        if self.wkday_feature: base_len += 1
        if self.future_costs_feature: base_len += 4*2
        return base_len # temp

class LimitOpt():
    def __init__(self, agent, env):
        self.agent = agent
        self.env = env
        self._replay = agent.agent._replay
        self._oracle_replay = agent.agent._oracle_replay
        self.parameter = agent.agent.limit_parameter
        self.optimizer = agent.agent.limit_optimizer
        self.logger = agent.logger
        self.writer = agent.writer
        self.step = 0

    def init_limit_training(self):
        agent = self.agent
        # if agent.learn_limits:
        #     agent.agent.limit_optimizer.zero_grad()
        #     valid_day_cnt = 0
        #     limit_loss = torch.tensor(0.).to(device=agent.agent.get_device())
        #     return valid_day_cnt, limit_loss
        # else: return None, None
        self.optimizer.zero_grad()
        self.valid_day_cnt = 0
        self.limit_loss = torch.tensor(0.).to(device=agent.agent.get_device())

    def init_daywise(self):
        agent = self.agent
        self.diff_day_r = torch.tensor(0.).to(device=agent.agent.get_device())

    def update_and_compute_loss(self,):
        agent, env = self.agent, self.env
        diff_day_r = self.diff_day_r
        # global diff_day_r, limit_loss, valid_day_cnt
        # if agent.learn_limits:
        tmp = env.compute_reward_powerlaw_differentiable(None, None, agent.get_limit_parameter(detach=False))
        self.diff_day_r += tmp
        if env.past_day_ends(): #and agent.learn_limits:
            day_r = env.compute_reward_sparse(None, None)   # 0.5 because powerlaw use 0.5
            # print('day reward', day_r)
            if day_r > 0:
                day_r *= 0.5 * env.num_slot_in_day
                loss = (day_r - diff_day_r) ** 2
                # loss.backward()
                self.limit_loss += loss
                self.valid_day_cnt += 1
                # self.logger.info('valid day {}'.format(self.valid_day_cnt))

    def occupancy_measure_loss(self):
        if self.multi_timescale:
            self.multiplier_optimizer.zero_grad()
            for it in range(self._replay.num_episode_iter()):
                roi_diff,rbr = self._replay.sample_episode_batch()
                # min_alpha -alpha[totalcost - B] (totalcost <=B)
                # B-totalcost => remaining budget, so -remain_budget_rate \propto totalcost-B
                # so the surrogate loss is alpha x rbr
                # min_alpha -alpha[Lcost-rev] (ROI>=L => rev >= Lcost => Lcost-rev <=0)
                # L-rev/cost \propto Lcost-rev
                # so the surrogate loss is alpha x (ROI-L)
                device = self.get_device()
                multiplier_loss = torch.tensor(0.).to(device)
                if self.log_multiplier[0] is not None:
                    multiplier_loss += (self.log_multiplier[0] )*roi_diff.mean()
                if self.log_multiplier[1] is not None:
                    multiplier_loss += (self.log_multiplier[1] )*rbr.mean()
                multiplier_loss.backward()
            # nn.utils.clip_grad_norm_(self.log_multiplier, max_norm=self.clip_norm)
            self.multiplier_optimizer.step()

    def debug(self):
        agent = self.agent
        if (self.valid_day_cnt>0) and (self.valid_day_cnt) % 3 == 0:
            # last = agent.agent.limit_parameter.clone()
            # self.logger.info('last limit {}'.format(last.item()))
            # agent.agent.limit_parameter.grad /= valid_day_cnt
            self.limit_loss /= self.valid_day_cnt
            self.limit_loss.backward()
            self.optimizer.step()
            # if torch.abs(agent.agent.limit_parameter-last)<1e-4:
            #     print()
            self.logger.info('limit {} with loss {}'.format(agent.get_limit_parameter(), self.limit_loss))
            self.step += 1

            self.writer.add_scalar('{}/limit'.format('train_stats'), self.parameter.item(), self.step)
            self.writer.add_scalar('{}/limit_loss'.format('train_stats'), self.limit_loss.item(), self.step)
            self.writer.add_scalar('{}/sqrt_limit_loss'.format('train_stats'), np.sqrt(self.limit_loss.item()), self.step)

            self.init_limit_training()

def train_or_test_synchronous_exp(env, agent, window_size, exploration_num, C, istest, epoch_it=0, git=0, max_perf=-np.inf, need_exploration=True, is_cem=False, save_margin=0.1):
    istrain = not istest
    logger = agent.logger
    writer = agent.writer
    st = time.time()
    # do_incremental = not (istest and not agent.test_incremental)
    update_during_train = istrain
    is_train_env = not istest
    # update_during_test = istest and agent.test_incremental

    min_day = env.get_day()
    max_day = env.how_many_days()
    logger.info('traverse from {} to {} days'.format(min_day, max_day))

    day_cnt = 0+epoch_it*max_day
    state_preserver = env.state_preserver

    is_linear = agent._get_model_name()=='Linear' and 'yewu' in env.data_ver
    # limit_loss, valid_day_cnt = init_limit_training(agent)
    if agent.learn_limits:
        opt = LimitOpt(agent, env)
        opt.init_limit_training()

    # agent.set_period_exploration_factor(0.9)
    if not istest:
        agent.set_execution(False)
        while env.get_day()<max_day:
            # traverse through single day
            obs = env.get_obs_both(0., False, avg_value=is_linear)
            if agent.learn_limits: opt.init_daywise()
            while True:
                # ratio->scaled->mulawed->token
                action = agent.batch_act_both(obs)
                ratio = agent.get_bid_ratio(None, action)

                po_rew, po_rew_normalized, has_rq = env.slot_step(action, ratio, False, agent.get_multiplier(), agent.get_limit_parameter())

                # if agent.learn_limits: opt.update_and_compute_loss()
                if has_rq and env.use_history:
                    state_preserver.add_to_history(obs)

                next_obs = env.get_obs_both(ratio, env.past_day_ends(), avg_value=is_linear)
                po_rew_normalized = agent.postprocess_reward(obs, ratio, next_obs, po_rew_normalized)
                env.step_logging(True, state_preserver, po_rew, po_rew_normalized, ratio, agent.output_dir,
                                 agent._get_model_name())

                state_preserver._reset_slot()

                # env gives next obs, pause to save the whole transition
                agent.update_buffer((obs, action, 0 if po_rew is None else po_rew_normalized, env.past_day_ends(), next_obs))

                obs = next_obs
                if env.get_day() > 0:
                    agent.learn(train_model=True, train_other=True)

                if env.test_period_ends():
                    env.update_each_period()  # update recent ratios and loose-win states

                if env.past_day_ends(): break

            if agent.learn_limits: opt.debug()

            env.dayover_stats_update()
            env.dayover_logging(False, state_preserver, agent.output_dir)
            agent.dayover_logging()
            state_preserver._reset_day()

            log_as_final = istest and day_cnt==env.how_many_days()-1

            window_perf,perf = report('test' if istest else 'train', env, agent, agent.output_dir,
                   base_day=day_cnt, logtypes_elim=None,
                   window_size=window_size, #window_size,
                   log_as_final=log_as_final,
                    max_perf=max_perf,
                    )

            logger.info('one day takes {}'.format(time.time() - st))
            logger.info('+' * 84)
            # agent._reset_day()
            st = time.time()
            day_cnt += 1

            if env.past_week_ends():
                env.weekover_logging(False, state_preserver)
        logger.info('max day {} reached'.format(max_day))
        logger.info('average value per slot, {}'.format(state_preserver.avg_value_sum / (max_day*env.num_slot_in_day)))

    logger.info('start val epoch')
    agent.eval()
    env.set_step(0)
    env.reset_traversal()
    agent.set_execution(True)
    while env.get_day()<max_day:
        # traverse through single day
        obs = env.get_obs_both(0., False, avg_value=is_linear)
        if agent.learn_limits: opt.init_daywise()
        while True: # eval还是同步存oracle
            action = agent.batch_act_both(obs)
            ratio = agent.get_bid_ratio(None, action)
            # env step with the action and gives feedbacks
            po_rew, po_rew_normalized, has_rq = env.slot_step(action, ratio, False, agent.get_multiplier(), agent.get_limit_parameter())  # this can be None
            # if agent.learn_limits: opt.update_and_compute_loss()
            if has_rq and env.use_history:
                state_preserver.add_to_history(obs)
            next_obs = env.get_obs_both(ratio, is_terminal=env.past_day_ends(), avg_value=is_linear)
            po_rew_normalized = agent.postprocess_reward(obs, ratio, next_obs, po_rew_normalized)
            env.step_logging(False, state_preserver, po_rew, po_rew_normalized, ratio, agent.output_dir,
                             agent._get_model_name())

            state_preserver._reset_slot()

            # env gives next obs, pause to save the whole transition
            agent.update_buffer(
                (obs, action, 0 if po_rew is None else po_rew_normalized, env.past_day_ends(), next_obs))

            obs = next_obs
            agent.learn(train_model=False, train_other=istrain) # train other if during eval (not test)

            if env.test_period_ends():
                env.update_each_period()  # update recent ratios and loose-win states

            if env.past_day_ends(): break

        if agent.learn_limits: opt.debug()
        env.dayover_stats_update()
        env.dayover_logging(True, state_preserver, agent.output_dir)
        agent.dayover_logging()
        state_preserver._reset_day()

        log_as_final = istest and day_cnt==env.how_many_days()-1

        window_perf,perf = report('eval' if not istest else 'test', env, agent, agent.output_dir,
               base_day=day_cnt, logtypes_elim=None,
               window_size=max_day,
               log_as_final=log_as_final,
                max_perf=max_perf,
                )

        logger.info('one day takes {}'.format(time.time() - st))
        logger.info('+' * 84)
        # agent._reset_day()
        st = time.time()
        day_cnt += 1

        if env.past_week_ends():
            env.weekover_logging(False, state_preserver)

    if istrain and window_perf > max_perf - 0.03: # 0.796 0.790
        scaler = state_preserver.get_reward_std()
        agent.save(0, scaler)
        env.save(agent.output_dir)
        if window_perf > max_perf:
            max_perf = window_perf
        logger.info('agent has been saved as 0 with {}({}), scaler {}'.format(perf, window_perf, scaler))
    else:
        logger.info(
            'agent score {}({} in window {})'.format(perf, window_perf, max_day))
    # if window_perf>max_perf-0.1:
    #     scaler = state_preserver.get_reward_std()
    #     agent.save(0, scaler)
    #     env.save(agent.output_dir)
    #     if window_perf>max_perf:
    #         max_perf = window_perf
    #     logger.info('agent has been saved as 0 with {}({}), scaler {}'.format(perf, window_perf, scaler))
    env.set_step(0)
    env.reset_traversal()
    agent.set_train()

    return max_perf

def train_before_test(is_sync, test_env, train_env, agent, model, test_day_unit, train_max_days, exploration_num, C, window_size, nepoch=1, gamma_nepoch=5, restore=False, do_random=True, init_b=0.2, save_margin=0.1):
    epoch_procedure = train_or_test_synchronous_exp if is_sync else train_or_test
    agent.set_train()
    max_perf = -np.inf
    if train_env is not None:
        if train_env.reward_type == 6:
            epochs = [5,5,5]
            # gamma_nepoch = nepoch
            # niter_each_epoch = 5
            base_cnt = 0
            # gammas = [0.2, 0.3, 0.4] # 决定一开始的constraint松弛20%
            if agent.tri_player:
                agent.logger.info('triplayer')
                for it in range(nepoch):
                    if do_random: train_env.randomize_days()
                    max_perf = epoch_procedure(train_env, agent, window_size, exploration_num, C, istest=False, epoch_it=it+base_cnt, git=0, max_perf=max_perf, save_margin=save_margin)
                    train_env.set_step(0)
                    # if (it+1)%3==0: agent.load(0)
                    # if (it+1)%5==0:
                    #     agent.load(0) # load from the best ckpt
                        # agent.clear_buffer()
            else:
                for git in range(gamma_nepoch):
                    pb = init_b+0.1*git # 0.8 enough
                    train_env.set_b(pb)
                #penalty: 10->100 gamma: 1.0->0.0 delta/1.0 * 10
                    # agent.penalty_scale *= (git+1)
                    if gamma_nepoch==1: niter_each_epoch = nepoch
                    elif gamma_nepoch==2: niter_each_epoch = 5 if git==0 else 10
                    else: niter_each_epoch = epochs[git]
                    # niter_each_epoch = nepoch if gamma_nepoch==1 else epochs[git]
                    for it in range(niter_each_epoch):
                        if do_random: train_env.randomize_days()
                        # print('num iter,', it+base_cnt)
                        max_perf = epoch_procedure(train_env, agent, window_size, exploration_num, C, istest=False, epoch_it=it+base_cnt, git=0, max_perf=max_perf, save_margin=save_margin)
                        train_env.set_step(0)
                        agent.load(0) # load from the best ckpt
                    agent.clear_buffer()
                    base_cnt += niter_each_epoch

                    # agent.load(0)
                train_env.save_mprice_model()
                test_env.set_b(pb) # need to set gamma for test env, otherwise error occur
        else:
            for it in range(nepoch):
                print('epoch {}'.format(it))
                if do_random: train_env.randomize_days()
                max_perf = epoch_procedure(train_env, agent, window_size, exploration_num, C, istest=False, epoch_it=it, max_perf=max_perf, save_margin=save_margin)
                train_env.set_step(0)
            train_env.save_mprice_model()

    agent.eval()
    if not restore:
        agent.load(0)
    epoch_procedure(test_env, agent, window_size, exploration_num, C, istest=True, max_perf=max_perf)
    test_env.save(agent.output_dir)

def make_agent(cfg, test, envname):
    size_getter = Observation(cfg)
    obs_size = size_getter.size
    mb_size = size_getter.mb_size
    agent = BaseAgent_discrete(cfg, obs_size, full_state_size=mb_size, test_mode=test, envname=envname)  # BidAgent()
    return agent

if __name__ == '__main__':
    args = make_parser()
    main(args, make_agent, train_before_test)