import numpy as np
import random
from collections import namedtuple, deque
from dopamine.replay_memory.circular_replay_buffer import ReplayElement
# from dopamine.jax.agents.sac import sac_agent

# from jax import numpy as jnp
# import jax
import collections
from collections import defaultdict
from networks import Network, StateActionValueNetwork, PolicyNetwork, StateManipulation, DoubleQCritic, Critic, \
    DoublePolicyNetwork, NaiveBuffer, Normalizer, DiscretePolicyNetwork
from runner_utils import sync_weights, core_reward_powerlaw_differentiable, get_numpy_from_tensor
import torch
import torch.nn.functional as F
from torch import nn
import torch.optim as optim
import os
from torch.optim import lr_scheduler
import pandas as pd
import configparser
import itertools


BUFFER_SIZE = int(1e6)  # replay buffer size
BATCH_SIZE = 24 * 2  # minibatch size
max_niter = 10
GAMMA = 1.0  # discount factor
TAU = 0.1  # for soft update of target parameters
LR = 0.001  # learning rate
UPDATE_EVERY = 4  # how often to update the network

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class SAC():
    """Interacts with and learns from the environment."""
    def __init__(self, cfg, state_size, action_size, seed, action_bound, shallow_state_emb_size=50, full_state_size=None, buffertype=4,
                 replay_scheme='uniform', discount=1.0, simplified=False):
        """Initialize an Agent object.

        Params
        ======
            state_size (int): dimension of each state
            action_size (int): dimension of each action
            seed (int): random seed
        """
        self.state_size = state_size
        self.store_state_size = state_size if full_state_size is None else full_state_size
        self.action_size = action_size
        self.seed = seed
        torch.manual_seed(self.seed)
        # self.tau = 0.1
        # self.seed = random.seed(seed)
        self._load_config(cfg)
        self.normalizer = Normalizer(cfg)
        # Q-Network
        if simplified:
            fc1_hidden = 20
        else:
            fc1_hidden = 30
        torch_seed = seed  # np.random.randint(10000)
        self.torch_seed = seed
        # networks: q; target q two nets respectively; one policy net
        self.sar_size = self.state_size + 2 if self.history_type=='sar' else 2*self.state_size+2
        if self.use_history:
            # if self.no_kl and self.encoder_type=='transformer2': mlp_in = self.history_emb_dim
            # else: mlp_in = shallow_state_emb_size + self.history_emb_dim
            mlp_in = shallow_state_emb_size + self.history_emb_dim
        else: mlp_in = shallow_state_emb_size

        self.state_normalizer = StateManipulation(cfg, state_size, obs_hidden_size=shallow_state_emb_size, full_obs_size=full_state_size,
                                                  use_bn=self.use_bn, value_in_state=self.ablation == 16,
                                                  use_history_encoder=self.use_history,
                                                  encoder_type=self.encoder_type,
                                                  history_emb_dim=self.history_emb_dim,
                                                  history_size=self.history_size,
                                                  history_type=self.history_type,
                                                  use_curiosity=self.use_curiosity).to(device)

        self.policy = self.get_actor(mlp_in, action_size, seed, action_bound, fc1_hidden, cfg)
        self.critic = self.get_critic(mlp_in, 16 if self.normalizer.tokenization and self.encoder_type=='transformer2' else action_size, # action as input
                                      seed, fc1_hidden, self.tau, cfg)

        self.networks = [self.critic, self.policy, self.state_normalizer]

        self.policy_opt = optim.Adam(self.policy.parameters(), lr=self.lr)
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=self.lr)
        self.optimizers = [self.policy_opt, self.critic_opt]

        if self.use_multiplier:
            log_mult = []
            if self.has_ROI_constraint:
                value = self.init_multiplier if self.init_multiplier>0 else np.random.uniform(0,4)
                tensor = torch.nn.Parameter(torch.tensor(value, dtype=torch.float32).to(device), requires_grad=True)
            else: tensor = None
            log_mult.append(tensor)
            if self.has_budget:
                value = self.init_multiplier if self.init_multiplier>0 else np.random.uniform(0,4)
                tensor = torch.nn.Parameter(torch.tensor(value, dtype=torch.float32).to(device), requires_grad=True)
            else: tensor = None
            log_mult.append(tensor)
            self.log_multiplier = log_mult
            self.multiplier_optimizer = torch.optim.Adam([x for x in log_mult if x is not None], lr=self.lr)
            # self.networks.append(self.log_multiplier)
            # self.optimizers.append(self.multiplier_optimizer) # don't participate in sched
        else: self.log_multiplier = None
        if self.learn_limits:
            limits = []
            if self.has_ROI_constraint:
                value = np.log(0.1)
                tensor = torch.nn.Parameter(torch.tensor(value, dtype=torch.float32).to(device), requires_grad=True)
            else:
                tensor = None
            limits.append(tensor)
            if self.has_budget:
                value = np.log(0.1)
                tensor = torch.nn.Parameter(torch.tensor(value, dtype=torch.float32).to(device), requires_grad=True)
            else:
                tensor = None
            limits.append(tensor)

            self.limit_parameter = limits
            self.limit_optimizer = torch.optim.Adam([x for x in limits if x is not None], lr=self.lr)
            if self.regret_minimization:
                value = np.log(0.1)
                self.regret_parameter = torch.nn.Parameter(torch.tensor(value, dtype=torch.float32).to(device), requires_grad=True)
                self.regretp_optimizer = torch.optim.Adam([self.regret_parameter], lr=self.lr)
            else: self.regret_parameter, self.regretp_optimizer = None, None
            # while L is updated three days each, model parameters are update every time slot with at most 10 iters
            # self.optimizers.append(self.limit_optimizer) # don't participate in sched
        else: self.limit_parameter = None

        # [x.set_normalizer(self.state_normalizer) for x in self.networks]
        # self.networks.append(self.state_normalizer)
        params = list(self.state_normalizer.parameters())
        if len(params)>0:
            self.normalizer_opt = optim.Adam(params, lr=self.lr)
            self.optimizers.append(self.normalizer_opt)
        else: self.normalizer_opt = None

        self._replay = self._build_replay_buffer()

        self._oracle_replay = None

        self.buffertype = buffertype
        # Initialize time step (for updating every UPDATE_EVERY steps)
        self.t_step = 0
        self._replay_scheme = replay_scheme  # prioritized
        self.reward_discount = discount

        self.scheduler = self.get_sched()

    def get_critic(self, mlp_in, action_size, seed, fc1_hidden, tau, cfg):
        return DoubleQCritic(cfg, mlp_in, action_size, seed, fc1_hidden=fc1_hidden, use_bn=self.use_bn, tau=self.tau).to(device)

    def get_actor(self, mlp_in, action_size, seed, action_bound, fc1_hidden, cfg=None):
        return PolicyNetwork(mlp_in, action_size, seed, action_bound=action_bound,
                      use_bn=self.use_bn).to(device)

    def reward_helper(self, trajs, alpha):
        # [t,ratio,roidif,L,rbr] [?,rev,?]
        L_idx = 3 if self.has_ROI_constraint else None  # currently assume that we always have roi constraints
        rbr_idx = (4 if self.has_ROI_constraint else 3) if self.has_budget else None
        roid_idx = L_idx - 1 if L_idx is not None else None
        # time ratio L roidiff rbr
        slot_rev_idx = 6
        if not self.has_budget: slot_rev_idx -= 1
        if not self.has_ROI_constraint: slot_rev_idx -= 2

        normalized_t = trajs[:, :, 0]  # (slotno+1)/nslot
        scaled_rev = trajs[:, :, slot_rev_idx]  # note that each step's rev has been scaled with self.slot_rev_scaler
        rbr, roidiff, rois, Ls = None, None, None, None
        if rbr_idx is not None: rbr = trajs[:, :, rbr_idx]
        if roid_idx is not None: roidiff = trajs[:, :, roid_idx]
        if L_idx is not None:
            Ls = trajs[:, :, L_idx]
            rois = roidiff + Ls
            # bs,h,
        bs = normalized_t.shape[0]
        differentiable_rewards = core_reward_powerlaw_differentiable(normalized_t, alpha, scaled_rev, rois, rbr, Ls)
        roi_sat = roidiff[...,-1]>=0 if roid_idx is not None else np.ones(bs, dtype=bool)
        budget_sat = rbr[...,-1]>=0 if rbr_idx is not None else np.ones(bs, dtype=bool)
        real_rewards = np.ones(bs, dtype=np.float32) * np.nan
        indexer = roi_sat & budget_sat

        real_rewards[indexer] = scaled_rev.sum(-1)[indexer]
        return differentiable_rewards, real_rewards, indexer


    def get_sched(self):
        sched = [lr_scheduler.MultiStepLR(opt, milestones=[10000, 20000, 30000], gamma=0.5) for opt in self.optimizers]
        return sched

    def get_niter(self):
        num_sample = self._replay.add_count
        max_batch = num_sample // self.batch_size
        return min(max_batch, max_niter)

    def eval(self):
        [x.eval() for x in self.networks]

    def set_train(self):
        [x.train() for x in self.networks]

    def _build_replay_buffer(self):
        """Creates the replay buffer used by the agent."""
        state_size = self.state_size if self.pe == 0 else self.state_size + 1
        extra_storage = []

        if self.buffer_old:
            return MyBuffer(
                observation_shape=(state_size,),
                action_dtype=np.float32,
                stack_size=1,
                replay_capacity=self.buffer_size,
                batch_size=self.batch_size,
                update_horizon=1,
                gamma=1,
                observation_dtype=np.float32,
                extra_storage_types=extra_storage,
            )
        else:
            return NaiveBuffer(
                observation_shape=(self.store_state_size,),
                inference_obs_size=self.state_size,
                action_dtype=np.float32 if not self.discrete_action else np.int64,
                stack_size=1,
                replay_capacity=self.buffer_size,
                batch_size=self.batch_size,
                update_horizon=1,
                gamma=1,
                observation_dtype=np.float32,
                extra_storage_types=extra_storage,
                require_nobs=True,
                use_history=self.use_history,
                history_size=self.history_size,
                history_type=self.history_type,
                sync=self.sync,
                horizon_length=self.num_slot_in_day,
                normalizer=self.normalizer,
                discrete_action=self.discrete_action,
                parallel_rewards=self.parallel_rewards
            )
        # return circular_replay_buffer.OutOfGraphReplayBuffer(
        #     observation_shape=(self.state_size,),
        #     stack_size=1,
        #     replay_capacity=self.buffer_size,
        #     batch_size=self.batch_size,
        #     update_horizon=1,
        #     gamma=1,
        #     observation_dtype=float)

    def clear_buffer(self):
        del self._replay
        self._replay = self._build_replay_buffer()

    def _load_config(self, cfg):
        """
        Parse the config.cfg file
        """
        # cfg = configparser.ConfigParser(allow_no_value=True)
        # # env_dir = os.path.dirname(__file__)
        # cfg.read('./config.cfg')
        self.cfg = cfg
        self.train_freq = eval(cfg['rl_agent']['train_freq'])  # in slots
        self.target_update_freq = eval(cfg['rl_agent']['target_freq'])  # default to 4 in slots
        self.buffer_size = eval(cfg['rl_agent']['buffer_size'])
        self.batch_size = eval(cfg['rl_agent']['batch_size'])
        self.min_history = self.batch_size
        self.lr = eval(cfg['rl_agent']['soft_q_lr'])
        self.pe = eval(cfg['rl_agent']['position_encoding'])
        self.use_bn = eval(cfg['rl_agent']['use_bn'])
        self.tau = eval(cfg['rl_agent']['tau'])
        self.ablation = eval(cfg['rl_agent']['ablation'])
        self.fc1_hidden = eval(cfg['rl_agent']['fc1_hidden'])
        self.use_history = eval(cfg['rl_agent']['use_history'])
        self.encoder_type = cfg['rl_agent']['encoder_type']
        self.no_kl = eval(cfg['rl_agent']['kl_factor'])==0.
        self.history_size = eval(cfg['rl_agent']['history_size'])
        self.history_emb_dim = eval(cfg['rl_agent']['history_emb_dim'])
        self.history_type = cfg['rl_agent']['history_type']
        # self.use_decoder = eval(cfg['rl_agent']['use_decoder'])
        self.stop_q_bp = eval(cfg['rl_agent']['stop_q_bp'])
        self.use_curiosity = eval(cfg['rl_agent']['use_curiosity'])
        self.curiosity_factor = eval(cfg['rl_agent']['curiosity_factor'])

        slot_len = eval(cfg['data']['slot_len'])
        self.num_slot_in_day = (60 // slot_len) * 24
        self.sync = eval(cfg['data']['synchronous'])
        self.buffer_old = eval(cfg['rl_agent']['buffer_old'])
        self.clip_norm = eval(cfg['rl_agent']['clip_norm'])
        self.use_multiplier = eval(cfg['rl_agent']['rewardtype']) == 3
        self.init_multiplier = eval(cfg['rl_agent']['init_multiplier'])
        self.multi_timescale = self.use_multiplier and not eval(cfg['rl_agent']['tune_multiplier']) # not tune multiplier means learning
        self.learn_limits = eval(cfg['rl_agent']['learn_limits'])
        self.tri_player = self.learn_limits and eval(cfg['rl_agent']['tri_player'])
        self.learn_limits = eval(cfg['rl_agent']['learn_limits'])
        data_ver = cfg['data']['version']
        self.has_budget = 'b' in data_ver
        self.has_ROI_constraint = 'L' in data_ver or 'f' in data_ver
        self.limit_init = eval(cfg['rl_agent']['powerlaw_b'])

        self.discrete_action = eval(cfg['rl_agent']['discrete_action'])

        self.parallel_rewards = False
        self.do_parallel = False
        self.regret_minimization = False

    def save(self, path, suffix, reward_scaler):
        names = ['critic', 'policy', 'state_normalizer']
        d = dict()

        for name,net in zip(names, self.networks):
            sd = net.state_dict()
            d[name] = sd
            # fpath = os.path.join(path, '{}_{}.pth'.format(name, suffix))
            # print('save to {}, '.format(fpath))
            # torch.save(sd, fpath)

        d['critic_opt'] = self.critic_opt.state_dict()
        d['policy_opt'] = self.policy_opt.state_dict()
        d['norm_opt'] = self.normalizer_opt.state_dict() if self.normalizer_opt else None
        d['reward_scaler'] = reward_scaler
        if self.use_multiplier:
            d['multiplier'] = self.log_multiplier
        if self.learn_limits:
            d['limits'] = self.limit_parameter

        fpath = os.path.join(path, '{}_{}.pth'.format('model', suffix))
        torch.save(d, fpath)

    def get_lr(self):
        return self.scheduler[0].get_lr()[0]

    def restore(self, path, suffix):
        names = ['critic', 'policy', 'state_normalizer']
        fpath = os.path.join(path, '{}_{}.pth'.format('model', suffix))
        if not os.path.exists(fpath):
            print('{} does not exist'.format(fpath))
            return None
        d = torch.load(fpath, map_location=torch.device('cpu'))
        for name, net in zip(names, self.networks):
            sd = d[name]
            # if not (name=='state_normalizer' and not self.use_bn):
            net.load_state_dict(sd, strict=False)
        # optimizer update lr
        for k in ['critic','policy']:
            d[k+'_opt']['param_groups'][0]['lr'] = self.get_lr()
        self.critic_opt.load_state_dict(d['critic_opt'])
        self.policy_opt.load_state_dict(d['policy_opt'])
        # no need to reload global params
        # if self.use_multiplier:
        #     self.log_multiplier = [torch.nn.Parameter(torch.tensor(x.item()).to(self.get_device()), requires_grad=True) if x is not None else None for x in d['multiplier']]
        #     self.multiplier_optimizer = torch.optim.Adam([x for x in self.log_multiplier if x is not None], lr=self.get_lr())
        # if self.learn_limits:
        #     self.limit_parameter = [torch.nn.Parameter(torch.tensor(x.item()).to(self.get_device()), requires_grad=True) if x is not None else None for x in d['limits']]
        #     self.limit_optimizer = torch.optim.Adam([x for x in self.limit_parameter if x is not None], lr=self.get_lr() * 10)
        if self.normalizer_opt:
            d['norm_opt']['param_groups'][0]['lr'] = self.get_lr()
            self.normalizer_opt.load_state_dict(d['norm_opt'])
        return d['reward_scaler']

    def update_memory2(self, tup, priority=None):
        last_obs, action, r, episode_done, obs = tup[:5]
        if len(tup)>5:
            epid_in_batch, cursor = tup[5:]
        else: epid_in_batch, cursor = None, None
        # if priority is None:
        #     if self._replay_scheme == 'uniform':
        #         priority = 1.
        #     else:
        #         priority = self._replay.sum_tree.max_recorded_priority
        if self.use_history: obs = obs[0]
        self.add_to_buffer(last_obs, action, r, episode_done, obs, epid_in_batch, cursor, is_oracle=False)

    def add_to_buffer(self, last_obs, action, r, episode_done, obs, epid_in_batch, cursor, is_oracle=False):
        replay = self._oracle_replay if is_oracle else self._replay
        if self.use_history:
            last_obs, history, num_history = last_obs  # remove the history

        if self.sync:
            replay.add(last_obs, action, r, episode_done, epid_in_batch=epid_in_batch, cursor=cursor)
            if episode_done:
                replay.add_terminal_state(obs, epid_in_batch=epid_in_batch)
        else:
            if self.buffer_old:
                replay.add(last_obs, action, r, episode_done)
            else:
                replay.add(last_obs, action, r, episode_done, epid_in_batch=epid_in_batch, cursor=cursor)
                if episode_done:
                    replay.add_terminal_state(obs, epid_in_batch=epid_in_batch)

    def ok_to_sample(self):
        if hasattr(self._replay, 'ok_to_sample'): return self._replay.ok_to_sample()
        else:
            return self._replay.add_count > self.batch_size and self.t_step % self.train_freq == 0

    def _sample_from_replay_buffer(self, ret=('policy',), indices=None):
        types = self._replay.get_transition_elements()
        if len(ret)==1:
            replay = self._oracle_replay if ret[0]=='oracle' else self._replay
            samples = replay.sample_transition_batch(indices=indices) # only used for oracle

            # if (self.t_step+1)%20==0:
            #     print(pd.DataFrame(samples['observation']).describe())
            #     print(pd.DataFrame(self.replay_elements['observation']).describe())
            self.replay_elements = samples
        else: # both
            # pre-allocate memory
            replay = self._replay
            bs = replay._batch_size
            samples = replay.sample_transition_batch()  # tuple of nparr
            indices = samples['indices']
            oracle_samples = self._oracle_replay.sample_transition_batch()
            oracle_indices = oracle_samples['indices']
            # indices = np.asarray(list(indices)+list(oracle_indices))
            self.replay_elements = dict()
            for element_type in types:
                if element_type.name=='indices': continue
                e1, e2 = samples[element_type.name], oracle_samples[element_type.name]
                if element_type.name=='history': # todo: save storage by merging history and sar
                    self.replay_elements[element_type.name] = tuple([np.concatenate([item1,item2], 0) for item1,item2 in zip(e1,e2)])
                else:
                    # shape = list(e1.shape)
                    # shape[0] *= 2
                    # init_arr = np.empty(shape, dtype=e1.dtype)
                    # init_arr[:bs] = e1
                    # init_arr[bs:] = e2
                    self.replay_elements[element_type.name] = np.concatenate([e1,e2], 0) #init_arr
            self.replay_elements['indices'] = indices # directly use the non-oracle indicies

    def compose_history(self, states, actions, next_states, rewards, histories, nums):
        """
        construct history for next states.
        histories are ordered in reverse order
        nums: list of ints
        """
        state_size = states.shape[1]
        if self.parallel_rewards:
            s = np.concatenate([states[:,np.newaxis], histories[0][:,:-1]],1) # bs,nseq,dim
            a = actions[:,:-1]
            r = rewards[:,:-1]

        else:
            s = np.concatenate([states[:, np.newaxis], histories[0][:,:-1]], 1)
            a = np.concatenate([actions[:, np.newaxis], histories[1][:, :-1]], 1)
            r = np.concatenate([rewards[:, np.newaxis], histories[2][:, :-1]], 1)

        next_histories = (s, a, r)
        next_nums = np.clip(nums+1, 0, self.history_size)
        return next_histories, next_nums

    def train_agent(self, iter_multiplier=1):
        # losses, amps, qmins, qmaxs, qstds, alosses, plosses, entropys, kls, mses, curs = [[] for _ in range(11)]
        d_all_losses = defaultdict(list)
        self.t_step += 1

        num_iter = self.get_niter()
        # mloss, mamp, mqmin, mqmax, mqstd,maloss,mploss,mentropy,mklloss,mmseloss, mcurloss = [None]*11
        if self.ok_to_sample():
            require_exp_types = ['policy']

            for _ in range(num_iter*iter_multiplier):
                self._sample_from_replay_buffer(require_exp_types)
                indices = self.replay_elements['indices']
                loss_weights = np.ones(self.replay_elements['observation'].shape[0])

                states = self.replay_elements['observation'] # .squeeze(-1)
                actions = self.replay_elements['action']
                rewards = self.replay_elements['reward']
                next_states = self.replay_elements.get('next_obs', None)
                terminals = self.replay_elements['terminal']


                oracle_history = None
                if self.use_history:
                    histories = self.replay_elements['history'] # use ratio instead of action
                    nums = self.replay_elements['num_history']

                    next_histories, next_nums = self.compose_history(states, actions,
                                                                     next_states, self.replay_elements['reward'], histories, nums)
                    experiences = ((states,histories, nums),
                                   actions, rewards,
                                   (next_states, next_histories, next_nums),
                                   terminals)

                else:
                    experiences = (states, actions, rewards, next_states, terminals)
                d_losses = self.learn(experiences, self.reward_discount, loss_weights, oracle_history=oracle_history)

                for k,v in d_losses.items():
                    d_all_losses[k].append(v)

            for k, v in d_all_losses.items():
                d_all_losses[k] = torch.stack(v).mean().cpu().item()
            # mloss, mamp, mqmin, mqmax, mqstd,maloss,mploss,mentropy = [torch.stack(x).mean().cpu().item() for x in
            #                                [losses, amps, qmins, qmaxs, qstds,alosses,plosses,entropys]]
            # if self.use_history:
            #     mklloss = torch.stack(kls).mean().cpu().item()
            #     if self.use_decoder: mmseloss = torch.stack(mses).mean().cpu().item()
            #     else: mmseloss = 0.
            # else:
            #     mklloss = 0.
            #     mmseloss = 0.
            #
            # if self.use_curiosity:
            #     mcurloss = torch.stack(curs).mean().cpu().item()
            # else: mcurloss = 0.

        if self.t_step % self.target_update_freq == 0:
            self.critic.sync_weights()
            self.policy.sync_weights() # can be ddpg
            # sync_weights(self.q1, self.target_q1, self.tau)
            # sync_weights(self.q2, self.target_q2, self.tau)
        return d_all_losses
        # return dict(qnet=[mloss, mamp, mqmin, mqmax, mqstd],others=[maloss,mploss,mentropy,mklloss, mmseloss, mcurloss])

    def train(self, iter_multiplier=1):
        ret = self.train_agent(iter_multiplier)
        return ret
        # if self.buffertype == 4:
        #     return self.per_train()
        # else:
        #     return self.normal_train()

    def get_multiplier(self):
        if self.use_multiplier:
            return [x.exp().item() if x is not None else None for x in self.log_multiplier]
        else: return [None, None]

    def get_limit_parameter(self, detach=True):
        if self.learn_limits:
            if detach: return [torch.clamp(x.detach().exp(), 0, 0.6).item() for x in self.limit_parameter]
            else: return [torch.clamp(x.exp(), 0, 0.6) for x in self.limit_parameter]
        else: return None

    def postprocess_reward(self, obs, action, nobs, rew):
        if self.use_curiosity:
            device = self.policy.get_device()

            # inp = np.concatenate([obs, [action]], axis=-1)[None].astype(np.float32)
            #
            # state = torch.from_numpy(inp).to(device)
            # with torch.no_grad():
            #     pred_nobs = self.state_normalizer.icm(state).cpu().numpy()[0]
            #
            # error = np.square(pred_nobs-nobs[2:4]).mean() / 2.
            # curiosity = error * self.curiosity_factor

            obs, action, nobs = [torch.FloatTensor([x]).to(device) for x in [obs, action, nobs]]
            diff, _, _ = self.state_normalizer.icm(obs, action, nobs)
            curiosity = self.curiosity_factor * diff.item()
            return rew + curiosity
        else:
            return rew

    def get_device(self): return self.policy.get_device()

    def act(self, state, eps=0., is_deterministic=False, allowed=None):
        """Returns actions for given state as per current policy.

        Params
        ======
            state (array_like): current state
            eps (float): epsilon, the probability of randomized greedy selection
        """

        # self.qnetwork_local.eval()
        flag = self.policy.training
        self.policy.eval()
        self.state_normalizer.eval()
        with torch.no_grad():
            # preprocess states for tokenization
            if self.use_history:
                new_s0 = self.normalizer.convert(state[0])
                history = state[1]
                states = self.normalizer.convert(history[0])
                actions = self.normalizer.convert_actions(history[1])
                rewards = self.normalizer.convert_rewards(history[2])
                new_s1 = (states,actions,rewards) # n,dim
                state = [new_s0, new_s1, state[-1]]
            else: state = self.normalizer.convert(state)
            ret = self.state_normalizer.forward(state, device=self.policy.get_device(), is_deterministic=is_deterministic)
            if self.encoder_type=='transformer3':
                obs_seq,a_seq,masks = ret['obs_seq'], ret['a_seq'], ret['masks']

                if not is_deterministic:
                    sampled_action, logp = self.policy.sample(obs_seq, masks, a_seq)
                    ret = sampled_action
                else:
                    _, scaled_mean, _, _, _ = self.policy.distr_params(obs_seq, masks, a_seq)
                    ret = scaled_mean
            else:
                state = ret['state']

                if not is_deterministic:
                    sampled_action, logp = self.policy.sample(state)
                    ret = sampled_action
                else:
                    _, scaled_mean, _, _, _ = self.policy.distr_params(state)
                    ret = scaled_mean
        self.state_normalizer.train(flag)
        self.policy.train(flag)
        return ret

    def learn(self, experiences, gamma=1., loss_weights=None, oracle_history=None):
        """
        oracle_history: tuple[history,num_history]
        """
        states, actions, rewards, next_states, dones = experiences
        device = self.policy.get_device()
        rewards = self.normalizer.revert_rewards(rewards)

        num_sample = actions.shape[0]
        zero_constant = torch.tensor(0.).to(device)
        forwardloss, sreconloss, invloss, kl_loss, mse_loss, curiosity_loss = [zero_constant]*6
        if not self.use_history:
            ret = self.state_normalizer.forward(np.concatenate([states,next_states], axis=0), device)
            tmp = ret['state']
            states, next_states = tmp[:num_sample], tmp[num_sample:]
            # kl_loss = 0.
            # mse_loss = 0.
        else: # will normalize history action inside this
            ret1 = self.state_normalizer.forward(states, device, action=actions)
            ret2 = self.state_normalizer.forward(next_states, device)
            states, next_states = ret1['state'], ret2['state'] # obs

            kl_loss = self.state_normalizer.forward_kl_loss(ret1['posterior'], prior=None)

            # kl_loss2 = ret2['kl_loss']
            # kl_loss = (kl_loss2+kl_loss1)/2.
        actions, rewards, dones = torch.from_numpy(actions).to(device), torch.from_numpy(rewards).to(
            device), torch.from_numpy(dones).to(device)
        if self.use_curiosity:
            curiosity_loss = self.state_normalizer.forward_curiosity_loss(states, actions, next_states)
        # else: curiosity_loss = 0.
        new_action_, new_action_logp, new_action_mean, entropy = self.policy.sample(states.detach(), keep_params=True)
        next_action, next_action_logp = self.policy.sample(next_states)
        new_action = new_action_

        # will not normalize actions in critic
        next_qv, target_qv = self.critic.target_qv(next_states, next_action, next_action_logp,
                                                   rewards, gamma, dones) # target_qv will be detached

        qloss, alpha_loss = self.critic.forward_loss(states.detach() if self.stop_q_bp else states, actions, -new_action_logp, entropy, target_qv)
        qloss = qloss.mean()
        if self.normalizer_opt: self.normalizer_opt.zero_grad()

        self.critic_opt.zero_grad()
        (alpha_loss+qloss+kl_loss+mse_loss+curiosity_loss+forwardloss+sreconloss+invloss).backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=self.clip_norm)
        if self.normalizer_opt: nn.utils.clip_grad_norm_(self.state_normalizer.parameters(), max_norm=self.clip_norm)
        self.critic_opt.step()
        if self.normalizer_opt: self.normalizer_opt.step()

        new_qv = self.critic.new_qv(states.detach(), new_action)
        alpha = self.critic.alpha
        # need to detach related states, if avg value in state
        # print(alpha, new_action_logp.mean().item(), new_qv.mean().item(), states.mean().item(), new_action.mean().item(), new_action_.mean().item())

        policy_loss = self.get_policy_loss(alpha, new_action_logp, new_qv, entropy, new_action_mean)
        self.policy_opt.zero_grad()
        policy_loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), max_norm=self.clip_norm)
        self.policy_opt.step()

        ret = dict(qnet_loss=qloss, qvalue_min=next_qv.min(), qvalue_max=next_qv.max(), qvalue_std=next_qv.std(),
                   alpha_loss=alpha_loss, policy_loss=policy_loss, policy_entropy=entropy.mean(),
                   kl_loss=kl_loss, decoder_mse=mse_loss, cur_loss=curiosity_loss,
                   forward_mse=forwardloss, srecon_mse=sreconloss, inverse_mse=invloss)
        return ret

    def get_policy_loss(self, alpha, new_action_logp, new_qv, entropy, new_action_mean):
        policy_loss = (alpha * new_action_logp - new_qv).mean()  # make policy close to q distribution
        return policy_loss

class DiscreteSAC(SAC):
    pass

class SQL(SAC):
    pass

class TransSAC2(SAC):
    pass



