# main purpose: find proper penalty when using weight decay scheduling for constraints, and use v12 feature
# 1: feature v12 v14
# 2: penalty scaler often 20
# 3: historytype sar or sasr
# yewu data
# feature history sync ep dataset
for ((i=1;i<=10;i++))
do
    python rl_bid_agent.py \
    --folder 000000CBRL_${1}_ep1_pb02_12_h${2}_GS5_sar_rnom0_sync1 --loading each --train_days 30  \
    --ablation 12 --use_history 1 --history_size ${2} --history_type sar --norm_reward 0 --synchronous 1 --data_ver ${1} \
    --rev_scaler 1 --penalty 1 --agent sac --reward 6 --powerlaw_b 0.35 \
    --fc1_hidden 40 --tau 0.1 --buffer_size 5000 --max_loss 30. --gamma 5 --test_with_ood \
    --slot 30 --buffer 4 --learn_limits 0 --tri_player 1 --replay 0 --nepoch 15 --gamma_nepoch 1 --force
done


#python rl_bid_agent.py \
#    --data_ver yewu_v4bL1 --folder debug \
#    --ablation 20 --use_history 1 --history_type sar --norm_reward 0 --synchronous 1 \
#    --rev_scaler 1 --penalty 1 --agent sac --reward 6 --powerlaw_b 0.2 \
#    --fc1_hidden 40 --tau 0.1 --buffer_size 5000 --max_loss 30. --gamma 4 \
#    --slot 30 --buffer 4 --replay 0 --nepoch 5 --gamma_nepoch 1 --force --oracle_history 1

#python rl_bid_agent.py \
#    --folder yewu_v3b_powerlawb02_16_h1_sar_rnom0_sync0_reconstr1 \
#    --ablation 16 --use_history 1 --history_type sar --use_decoder --reconstr_num 1 --norm_reward 0 --synchronous 0 --data_ver yewu_v3b \
#    --rev_scaler 1 --penalty 1 --agent sac --discount 0.97 --gamma 0.9 --reward 6 --powerlaw_b 0.2 \
#    --fc1_hidden 40 --tau 0.1 --buffer_size 5000 --max_loss 30. \
#    --slot 30 --train_days 40 \
#    --buffer 4 --replay 0 --nepoch 5 --gamma_nepoch 1 --force
#python rl_bid_agent.py \
#--folder yewu_v3_b08_powerlawb02_12_h1_sar_sync1 \
#--budget 0.8 --ablation 12 --use_history 1 --history_type sar --synchronous 1 --data_ver yewu_v3 \
#--rev_scaler 1 --penalty 1 --agent sac --discount 0.97 --gamma 0.9 --reward 6 --powerlaw_b 0.2 \
#--fc1_hidden 40 --tau 0.1 --buffer_size 5000 --max_loss 30. \
#--slot 30 --train_days 40 \
#--buffer 4 --replay 0 --nepoch 20 --gamma_nepoch 1 --force

#python rl_bid_agent.py --test_only --rev_scaler 1e-4 --discount 0.97 --gamma 0.90 --buffer_size 5000 --penalty 100 --reward 11 --folder eval_yewu_f$0_9790 --data_ver yewu --loading each --ablation 0 --train_days 40 --buffer 4 --replay 0 --slot 30 --nepoch 8