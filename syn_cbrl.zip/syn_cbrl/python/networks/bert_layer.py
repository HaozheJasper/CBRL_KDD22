"""
BERT layers from the huggingface implementation
(https://github.com/huggingface/transformers)
"""
# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors and The HuggingFace Inc. team.
# Copyright (c) 2018, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import logging
import math

import torch
from torch import nn
from .tools import _init_weights
# from apex.normalization.fused_layer_norm import FusedLayerNorm as BertLayerNorm



logger = logging.getLogger(__name__)


def gelu(x):
    """Implementation of the gelu activation function.
        For information: OpenAI GPT's gelu is slightly different (and gives slightly different results):
        0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * torch.pow(x, 3))))
        Also see https://arxiv.org/abs/1606.08415
    """
    return x * 0.5 * (1.0 + torch.erf(x / math.sqrt(2.0)))


def swish(x):
    return x * torch.sigmoid(x)


ACT2FN = {"gelu": torch.nn.functional.gelu, "relu": torch.nn.functional.relu, "swish": swish}


class GELU(nn.Module):
    def forward(self, input_):
        output = gelu(input_)
        return output


class BertSelfAttention(nn.Module):
    def __init__(self, config):
        super(BertSelfAttention, self).__init__()
        self.hidden_size = eval(config['bert']['hidden_size'])
        self.num_attention_heads = eval(config['bert']['num_attention_heads'])
        self.attention_probs_dropout_prob = eval(config['bert']['attention_probs_dropout_prob'])
        if self.hidden_size % self.num_attention_heads != 0:
            raise ValueError(
                "The hidden size (%d) is not a multiple of the number of attention "
                "heads (%d)" % (self.hidden_size, self.num_attention_heads))
        self.num_attention_heads = self.num_attention_heads
        self.attention_head_size = int(self.hidden_size / self.num_attention_heads)
        self.all_head_size = self.num_attention_heads * self.attention_head_size

        self.query = nn.Linear(self.hidden_size, self.all_head_size)
        self.key = nn.Linear(self.hidden_size, self.all_head_size)
        self.value = nn.Linear(self.hidden_size, self.all_head_size)

        self.dropout = nn.Dropout(self.attention_probs_dropout_prob)
        self.apply(_init_weights)

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(self, kv_inp, attention_mask, q_inp=None):
        """
        attention mask should be in shape bs,1,nseq,nseq
        """
        # todo: past values to prevent recompute
        hidden = kv_inp
        mixed_key_layer = self.key(hidden)
        mixed_value_layer = self.value(hidden)

        mixed_query_layer = self.query(q_inp) if q_inp is not None else self.query(kv_inp)

        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)
        
        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(self.attention_head_size)
        # Apply the attention mask is (precomputed for all layers in BertModel forward() function)
        attention_scores = attention_scores + attention_mask

        # Normalize the attention scores to probabilities.
        attention_probs = nn.Softmax(dim=-1)(attention_scores)

        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        attention_probs_drop = self.dropout(attention_probs)

        context_layer = torch.matmul(attention_probs_drop, value_layer)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_layer_shape)

        return context_layer,attention_probs


class BertSelfOutput(nn.Module):
    def __init__(self, config):
        super(BertSelfOutput, self).__init__()
        self.hidden_size = eval(config['bert']['hidden_size'])
        self.hidden_dropout_prob = eval(config['bert']['hidden_dropout_prob'])
        self.dense = nn.Linear(self.hidden_size, self.hidden_size)
        # self.LayerNorm = BertLayerNorm(self.hidden_size, eps=1e-12)
        self.LayerNorm = nn.LayerNorm(self.hidden_size, eps=1e-12)

        self.dropout = nn.Dropout(self.hidden_dropout_prob)
        self.apply(_init_weights)

    def forward(self, hidden_states, input_tensor):
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)
        return hidden_states


class BertAttention(nn.Module):
    def __init__(self, config):
        super(BertAttention, self).__init__()
        self.self = BertSelfAttention(config)
        self.output = BertSelfOutput(config)

    def forward(self, input_tensor, attention_mask, cross_input=None):
        self_output,attention_probs = self.self(input_tensor, attention_mask, cross_input)
        attention_output = self.output(self_output, input_tensor)
        return attention_output,attention_probs


class BertIntermediate(nn.Module):
    def __init__(self, config):
        super(BertIntermediate, self).__init__()
        self.hidden_size = eval(config['bert']['hidden_size'])
        self.intermediate_size = eval(config['bert']['intermediate_size'])
        self.hidden_act = eval(config['bert']['hidden_act'])
        self.dense = nn.Linear(self.hidden_size, self.intermediate_size)
        if isinstance(self.hidden_act, str):
            self.intermediate_act_fn = ACT2FN[self.hidden_act]
        else:
            self.intermediate_act_fn = self.hidden_act
        self.apply(_init_weights)

    def forward(self, hidden_states):
        hidden_states = self.dense(hidden_states)
        hidden_states = self.intermediate_act_fn(hidden_states)
        return hidden_states


class BertOutput(nn.Module):
    def __init__(self, config):
        super(BertOutput, self).__init__()
        self.hidden_size = eval(config['bert']['hidden_size'])
        self.intermediate_size = eval(config['bert']['intermediate_size'])
        self.hidden_dropout_prob = eval(config['bert']['hidden_dropout_prob'])
        self.dense = nn.Linear(self.intermediate_size, self.hidden_size)
        # self.LayerNorm = BertLayerNorm(self.hidden_size, eps=1e-12)
        self.LayerNorm = nn.LayerNorm(self.hidden_size, eps=1e-12)
        self.dropout = nn.Dropout(self.hidden_dropout_prob)
        self.apply(_init_weights)

    def forward(self, hidden_states, input_tensor):
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)
        return hidden_states


class BertLayer(nn.Module):
    def __init__(self, config):
        super(BertLayer, self).__init__()
        self.attention = BertAttention(config)
        self.intermediate = BertIntermediate(config)
        self.output = BertOutput(config)


    def forward(self, hidden_states, attention_mask, encoder_hidden=None):
        
        attention_output,attention_probs = self.attention(hidden_states, attention_mask, encoder_hidden)
        intermediate_output = self.intermediate(attention_output)
        layer_output = self.output(intermediate_output, attention_output)
        return layer_output,attention_probs
