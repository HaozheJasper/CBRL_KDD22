# gato
import numpy as np
import torch
import torch.nn as nn
MU=10
def mu_law_encode(x, mu=MU, m=1): # np input
    # Appendix B. Agent Data Tokenization Details
    sign = np.sign(x)
    numerator = np.log(np.abs(x) * mu + 1.0)
    denominator = np.log(m * mu + 1.0)
    return (numerator / denominator) * sign

def mu_law_decode(y, mu=MU, m=1):
    sign = np.sign(y)
    numerator = np.power((1.0 + m * mu), np.abs(y)) - 1.0
    denominator = mu
    return (numerator / denominator) * sign


def tokenize_continuous_values(x, mu=MU, m=1, bins=256, use_mulaw=True):
    """
    out: [0,256], both included
    """
    # Appendix B. Agent Data Tokenization Details
    # > Finally, they are discretized using bins of uniform width on the domain [-1, 1].
    # if np.isnan(x): # use pads
    #     return np.ones(x.shape, dtype=np.int64) * bins # bins is the max pad

    if use_mulaw: c = mu_law_encode(x, mu, m) # [-1,1]
    else: c = x

    # > We use 1024 bins and shift the resulting integers
    # > so they are not overlapping with the ones used for text tokens.
    c = (c + 1) * (bins / 2)
    if isinstance(c, np.ndarray):
        c[np.isnan(c)] = bins # bins is the max pad idx
    c = c.astype(np.int64)
    # if shift is not None:
    #     c += shift
    return c

def _init_weights(module):
    if isinstance(module, (nn.Linear, nn.Embedding)):
        torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
        if isinstance(module, nn.Linear) and module.bias is not None:
            torch.nn.init.zeros_(module.bias)
    elif isinstance(module, nn.LayerNorm):
        torch.nn.init.zeros_(module.bias)
        torch.nn.init.ones_(module.weight)

class Normalizer():
    def __init__(self, cfg):
        self.cfg = cfg
        self.tokenization = False
        self.budget_braking = eval(cfg['rl_agent']['budget_braking'])
        self.ratio_start = eval(self.cfg['rl_agent']['action_lo'])
        self.ratio_end = eval(self.cfg['rl_agent']['action_hi'])
        self.ratio_center = (self.ratio_start + self.ratio_end) / 2.
        self.ratio_scale = (self.ratio_end - self.ratio_start) / 2.

        self.vocab_size = 256

        # [-1.5,2]
        self.reward_ub, self.reward_lb = 2, -1.5
        self.reward_center = (self.reward_ub+self.reward_lb) / 2.
        self.reward_scale = (self.reward_ub-self.reward_lb) / 2.
        # self.rbr_center = 0.5 if self.budget_braking else 0 # [0,1] [-1,1]
        # self.rbr_scale = 1 if self.budget_braking else 2
        self.rbr_ub, self.rbr_lb = (1.0, 0.) if self.budget_braking else (1.,-1.)
        self.ablation = eval(cfg['rl_agent']['ablation'])
        self.feature_type = self.ablation
        data_ver = cfg['data']['version']
        self.has_budget = 'b' in data_ver
        self.has_roi_constraints = 'L' in data_ver or 'f' in data_ver


        code = [0,1] # t-step ratio
        if self.has_roi_constraints:
            code.extend([2,3])
        if self.has_budget:
            code.append(4)
        feature_type = self.feature_type
        if feature_type>=12:
            code.extend([5,6,7])
            if feature_type == 13:
                code.extend([8,9,10])
            elif feature_type == 14:  # no last
                code.append(8) # , adj_revrate, adj_costrate]
            elif feature_type == 15:  # best
                code.extend([8,9])
            elif feature_type == 16:  # no last
                code.append(8)
            elif feature_type == 18:  # 14+avg_valeu
                code.extend([8,9,10])
        self.code = code
        # target center:0; target scale: 2
        # t_step, ratio, roi_diff_cum, L, rbr, roi_diff_lastslot, last_real_rev, surplus, this_roi, adj_revrate, adj_costrate
        # self.centers = np.array([0.5, self.ratio_center, 0, 1., self.rbr_center, 0., 0., 0., 1.5, 2.5, 2.5], dtype=np.float32)
        # self.scales = np.array([1., self.ratio_scale, 3., 1., self.rbr_scale, 3., 20., 40., 3., 5., 5.], dtype=np.float32) / 2.
        self.ubs = np.array([1., self.ratio_end, 1.5, 1.5, self.rbr_ub, 1.5, 10., 20., 3., 5., 5.,], dtype=np.float32)
        self.lbs = np.array([0., self.ratio_start, -1.5, 0.5, self.rbr_lb, -1.5, -10., -20., 0., 0., 0. ], dtype=np.float32)
        self.centers = (self.ubs+self.lbs) / 2.
        self.scales = (self.ubs-self.lbs) / 2.
        # 2: -1.5<roidiff<1.5
        # 3: 0.5<L<1.5
        # 4: 0<1-cost/B<1, remaining budget = B-cost, if budget_braking; else: -1,1
        # 5: roidiff
        # 6: -10<lastrev<10
        # 7: -20<surplus<20
        # 8: 0<roi<3
        # 9: 0<adjr<5

    def padding(self):
        return self.centers[self.code]

    def convert(self, raw, code=None, force=False):
        if self.tokenization or force:
            if code is None: code = self.code[:raw.shape[-1]]
            shift = (raw - self.centers[code])
            normed = shift / self.scales[code]
            return normed
        else: return raw

    def convert_reconstruction_labels(self, tensor, num):
        code = self.code[-num:]
        ndim = len(tensor.shape)
        centers = torch.from_numpy(self.centers[code].reshape([1]*(ndim-1)+[-1])).to(tensor.device)
        scales = torch.from_numpy(self.scales[code].reshape([1] * (ndim - 1) + [-1])).to(tensor.device)
        normed = (tensor - centers) / scales
        return normed

    def bound(self, raw):
        code = self.code[:raw.shape[-1]]
        return np.clip(raw, self.lbs[code], self.ubs[code])

    def convert_actions(self, a): # ratio->scaled
        if self.tokenization:
            tmp = (a - self.ratio_center) / self.ratio_scale # to scale=2
            # if (tmp>1).any() or (tmp<-1).any():
            #     print()
            return tmp

        else: return a

    def convert_rewards(self, r):
        if self.tokenization:
            r = np.clip(r, self.reward_lb, self.reward_ub)
            tmp = (r-self.reward_center)/self.reward_scale
            # if (tmp > 1).any() or (tmp < -1).any():
            #     print()
            return tmp
        else: return r

    def revert_rewards(self, r):
        if self.tokenization:
            r = r*self.reward_scale + self.reward_center
        return r


    def token2ratio(self, token, use_mulaw=False): # ratio->scaled->mulawed->token
        # [0,bins) -> [-1,1]
        scaled = self.token2scaled(token, use_mulaw)
        return self.scaled2ratio(scaled)

    def token2scaled(self, token, use_mulaw=False):
        bin_size = 2. / self.vocab_size
        mu_value = -1. + token * bin_size + 0.5 * bin_size
        if use_mulaw: scaled = mu_law_decode(mu_value)  #
        else: scaled = mu_value
        return scaled

    def token2value(self, token, from_idx, use_mulaw=False):
        scaled = self.token2scaled(token, use_mulaw)
        scales = torch.from_numpy(self.scales[self.code[-from_idx:]].reshape((1,-1))).to(token.device)
        centers = torch.from_numpy(self.centers[self.code[-from_idx:]].reshape((1, -1))).to(token.device)
        values = scaled * scales + centers
        # values = []
        # for idx in range(-from_idx, 0, 1):
        #     scale = self.scales[self.code[idx]]
        #     center = self.centers[self.code[idx]]
        #     value = scaled[...,idx] * scale + center
        #     values.append(value)
        # values = torch.stack(values, dim=len(token.shape)-1)
        return values

    def scaled2ratio(self, scaled):
        ratio = scaled * self.ratio_scale + self.ratio_center
        return ratio

    def tokenize_continuous_values(self, x, mu=MU, m=1, bins=256, use_mulaw=False):
        """
        out: [0,256], both included
        """
        # Appendix B. Agent Data Tokenization Details
        # > Finally, they are discretized using bins of uniform width on the domain [-1, 1].
        # if np.isnan(x): # use pads
        #     return np.ones(x.shape, dtype=np.int64) * bins # bins is the max pad

        if use_mulaw:
            sign = torch.sign(x)
            numerator = torch.log(torch.abs(x) * mu + 1.0)
            denominator = np.log(m * mu + 1.0)
            return (numerator / denominator) * sign
        else:
            c = x

        # > We use 1024 bins and shift the resulting integers
        # > so they are not overlapping with the ones used for text tokens.
        c = (c + 1) * (bins / 2)
        c[torch.isnan(c)] = bins

        c = c.to(torch.long)
        # if shift is not None:
        #     c += shift
        return c




