import os

import numpy as np
import pandas as pd
import seaborn as sns
from tqdm import tqdm
import matplotlib.pyplot as plt
import os.path as osp
import configparser
import itertools
import pickle as pkl
import time
from collections import OrderedDict
import random
import logging
from scipy.ndimage.filters import gaussian_filter1d
from scipy import sparse
from collections import defaultdict
gen_mode = 'normal'
if gen_mode=='normal':
    raise_mean_cost = False
    poison_rev = True
    rev_flunc = 0.8,1.2
    rev_dev = 0.1
    roi_hi_span = 4,8 # 8,15
    cost_hi_span = 4,8 # 8,15
    cost_amp_lo = 0.4,0.5 # 0.4, 0.6
    cost_amp_hi = 0.5,0.7 # 0.6, 0.9
    roi_factor = 1.0 # 1.5
    start_day, num_day = 0, 60 # 10, 5
else:
    raise_mean_cost = True

    poison_rev = True
    rev_flunc = 0.7, 1.3
    rev_dev = 0.2
    roi_hi_span = 8,12
    cost_hi_span = 8,12
    cost_amp_lo = 0.4, 0.6
    cost_amp_hi = 0.6, 0.9
    roi_factor = 1.2
    start_day, num_day = 60, 20
names = [
    # 'k',
    'bidid',
    # 'time',
    'wkday',
    'hr',
    'min',
    'nick',  # length-n list random sample
    'pid',  # length-266 list random sample
    # 'all',
    # 'k2',
    # 'dsp_pctr',
    'pppc',  # predicted one, accurate one use rev
    # 'sessid',
    # 'creativeid',
    'pctr',
    # 'upbidprice',
    # 'exptime',
    'costprice',
    # 'clk1',
    # 'clk2',
    'click',
    'rev'
]

# yewu data stats
num_nick = 930925
num_pid = 266
# days_unique = np.arange(0, 14, 1)
hours_unique = np.arange(0, 24, 1)
mins_unique = np.arange(0, 60, 1)
nicks_unique = np.arange(0, num_nick, 1)
pids_unique = np.arange(0, num_pid)


def gumbel_pdf(x, mu=0, beta=1):
    z = (x - mu) / beta
    return np.exp(-z - np.exp(-z)) / beta


# print(gumbel_pdf(0.5, 0.5, 2))


class interfaces():
    def __init__(self, seed, iid):

        self.iid = iid
        self.set_seed(seed)
        self.costs, self.ctrs, self.rev_after_clk1, self.clicks, self.has_rev, self.revs, self.pctrs, self.pppcs = None, None, None, None, None, None, None, None

    def set_seed(self, seed):
        self.seed = seed
        random.seed(seed)
        np.random.seed(seed)

    def generate(self, size=1):
        pass

    def sample_pv(self, days, size=1):
        print('sample pv')
        # pass

    def sample_cost(self, size=1):
        print('sample cost')

    def sample_loose(self, size=1):
        print('sample loose')

    def sample_ctr(self, size=1):
        print('sample ctr')

    def sample_rev_after_clk1(self, size=1):
        print('sample rev')

    def generate_pctr(self):
        print('generate pctr')

    def generate_pppc(self):
        print('generate pppc')

    def generate_rev(self):
        print('generate rev')

    def sample_pctr(self, size=1):
        print('sample pctr')

    def sample_pppc(self, size=1):
        print('sample ppc')


left_factor = 2.44
gamma = 0.5772


class YewuSampler2(interfaces):
    def __init__(self, seed=0, istest=False, num_days=1, iid=False, minimal=True, data_ver=None):
        super(YewuSampler2, self).__init__(seed=seed, iid=iid)
        self.num_day = num_days
        self.istest = istest
        self.distrs = self.get_distr_from_meta()
        cfg = configparser.ConfigParser(allow_no_value=True)
        cfg.read('./config.cfg')
        self.num_pids = eval(cfg['data']['num_pid'])  # 180
        self.num_users = eval(cfg['data']['num_user'])  # 1024 # this much clusters
        self.num_aders = eval(cfg['data']['num_ader'])  # 300 # this much clusters
        self.data_ver = data_ver
        self.raise_percent = 0.3  # raise how much percent upon the cost
        self.affinity_percent = 0.1  # how much percent user-ad pair will raise
        # control the errors
        self.elevation_percent = 0.3
        self.degradation_percent = 0.6
        self.test_factor = 1.0 if istest else 1.0

        self.logger = None
        self.minimal = minimal
        # 5.16, 10.4, 16.9, 25.9
        self.low_med, self.low_mean, self.hi_med, self.hi_mean = 5.16, 19.4, 5.16, 27  # 偏低竞得率会高一点

        self.ctr_scaler = 1.
        self.rev_scaler = 1*70

        # if logger is None:
        #     self.logger = self.get_logger()
        # else: self.logger = logger

    def get_logger(self):
        logger = logging.getLogger('default')
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')
        streamhandler = logging.StreamHandler()
        streamhandler.setLevel(logging.DEBUG)
        streamhandler.setFormatter(formatter)
        # filehandler = logging.FileHandler(os.path.join(self.output_dir, 'log.txt'))
        # filehandler.setLevel(logging.DEBUG)
        # filehandler.setFormatter(formatter)
        logger.addHandler(streamhandler)
        # logger.addHandler(filehandler)

        # self.logger = logger
        return logger

    def set_logger(self, logger):
        print('logger set')
        self.logger = logger

    def sample(self, days, original_days):
        """
        generate data of the specified `days`
        """
        if self.logger is None:
            self.logger = self.get_logger()
        # 成本/点击率/实际点击收入
        # self.num_day = len(days)
        size = self.day2nrq[days].sum()
        self.sample_pv(days, original_days) # pid time
        self.sample_cost(days, size)

        self.ctrs = self.sample_ctr(size) # gumbel with mean/mode same as yewu
        self.sample_rev_after_clk1(days, size) # gumbel 0.6mode 1.0exp
        self.clicks, self.revs = self.generate_rev(self.ctrs, self.rev_after_clk1)
        # self.pppcs = self.generate_pppc(self.rev_after_clk1)
        # self.generate_pctr()
        self.pctrs = np.clip(self.ctrs, 1e-4, 1 - 1e-4)
        self.sample_loose(size)
        self.sample_pid(days)


    def get_distr_from_meta(self):
        return None

    def find_oracle_each_day(self, slot=30, plot=False, find=True):
        df = self.data
        self.logger.info('finding oracle')
        # if data is not None:
        #     df = data
        # else:
        #     df = pd.read_csv('../data/{}'.format(fname))
        # unique_days = df.day_no.unique()
        # import ipdb; ipdb.set_trace()
        # df['day_no'] = df['wkday'].map({k: idx for idx, k in enumerate(df.wkday.unique())})
        # if 'pppc' not in df.columns:
        #     df = df.rename(columns=dict(ppc='pppc'))

        num_slot_in_hour = 60 // slot
        num_slot_in_day = 24*num_slot_in_hour
        cols = df.columns
        if 'time_slot' not in df: df['time_slot'] = num_slot_in_hour * df.hr + df['min'] // slot
        # if 'value' not in df: df['value'] = df.pppc * df.pctr * 1e3
        # df['oracle'] = 0.
        # df['slot_oracle'] = 0.
        # oracle_col = []
        # slot_oracle_col = []
        # oracles = dict()
        # slot_oracles = dict()
        costs = []
        roiss = []
        oracles = []
        slot_oracles = []
        describes = defaultdict(dict)
        for day, dgroup in df.groupby('day_no'):
            self.logger.info(day)
            if find:
                day_thrsh, ccost, day_rrev, day_wr, day_roi = find_oracle(dgroup.rev, dgroup.costprice, dgroup.pppc*dgroup.pctr*1e3, prt=True)
                # oracle_col.extend([thrsh] * dgroup.shape[0])
                oracles.append(day_thrsh)

            rois = []
            day_slot_oracles = dict()
            k2r, k2c = 0, 0
            for slotid, sgroup in tqdm(dgroup.groupby('time_slot')):
                if False:
                    thrsh, ccost, rrev, slot_wr, slot_roi = find_oracle(sgroup.rev, sgroup.costprice, sgroup.value)
                    # ccost = rrev/slot_roi
                    k2r+=rrev
                    k2c+=ccost
                    # sgroup.loc[:, 'slot_oracle'] = thrsh
                    # slot_oracle_col.extend([thrsh] * sgroup.shape[0])
                    day_slot_oracles[slotid] = thrsh
                ret = sgroup.describe()
                describes[day][slotid] = ret[['pppc','pctr','click','costprice','rev']]
                if plot:
                    costs.append(sgroup.costprice.mean())
                    tmp = sgroup[sgroup.rev>0]
                    roi = tmp.rev / tmp.costprice * 1e3
                    rois.append(np.histogram(roi, bins=100))
            if find:
                self.logger.info('day {} roi thresh {} roi {} rev={}, wr={}'.format(day, day_thrsh, day_roi, day_rrev, day_wr))
                # self.logger.info('k2 roi {}, rev={}'.format(k2r/k2c, k2r))
                # self.logger.info('k2 gap: {}'.format(k2r-day_rrev))
            roiss.extend(rois)
            slot_oracles.append(day_slot_oracles)

        # df['oracle'] = oracle_col
        # df['slot_oracle'] = slot_oracle_col

        self.data = df[cols]
        # print(pd.concat([describes[day][i].loc['mean'] for i in range(num_slot_in_day)], 1).T)
        return costs, roiss, oracles, slot_oracles, describes

    def clear(self):
        del self.pids, self.users, self.ader, self.days, self.hours, self.mins, \
                    self.costs, self.ctrs, self.rev_after_clk1, self.clicks, self.revs, \
                    self.pctrs, self.pppcs, self.bidprices

    def produce(self, offseted_days, original_days, plot=False):
        self.sample(offseted_days, original_days)

        pids, users, aders, days, hrs, mis, costs, ctrs, rev_after_buy, clicks, revs, pctrs, pppcs, \
        bidprices = self.pids, self.users, self.ader, self.days, self.hours, self.mins, \
                    self.costs, self.ctrs, self.rev_after_clk1, self.clicks, self.revs, \
                    self.pctrs, self.pppcs, self.bidprices

        df = pd.DataFrame(dict(
            # bidid=ids.astype(np.int32),
                               day_no=days.astype(np.int32),
                               # wkday=wkdays.astype(np.int32),
                               hr=hrs.astype(np.int32),
                               min=mis.astype(np.int32),
                               # nick=users.astype(np.int32),
                               # ader=aders.astype(np.int32),
                               # pid=pids.astype(np.int32),
                               # ppc=rev_after_buy.astype(np.int32),
                               pppc=pppcs.astype(np.float32),
                               # ctr=ctrs.astype(np.float32),
                               pctr=pctrs.astype(np.float32),
                               click=clicks.astype(np.int32),
                               costprice=costs.astype(np.int32),
                               rev=revs.astype(np.int32),
                               # loose=loose.astype(np.bool),
                               # bidprice=np.round(bidprices).astype(np.int32)
        )
        )
        self.clear()
        # import ipdb; ipdb.set_trace()
        # final = df.sort_values(['wkday','hr','min'])
        # check
        values = df.pppc * df.pctr * 1000.
        # import ipdb; ipdb.set_trace()
        won = values > df.costprice
        roi = df[won].rev.sum() / (df[won].costprice.sum() / 1000.)
        self.logger.info('truth telling roi: {}, winnum={}'.format(roi, won.sum()))
        # import ipdb; ipdb.set_trace()
        final = df
        for day, tmp in final.groupby('day_no'):
            # import ipdb; ipdb.set_trace()
            # tmp = final[final.day_no == day]
            self.logger.info('day {} {} bids'.format(day, tmp.shape[0]))

        p = 0.8
        # df['loose'] = np.random.rand(df.shape[0])<p # p much is lost
        # final.to_csv('../data/{}'.format(fname), mode='w', index=False)
        # print(fname)
        # print('dump finish')
        return final

    def get_high_roi_hours(self, num_day,):
        np.random.seed(0)
        random.seed(0)
        if self.data_ver=='syn_v4':
            num_high_each = np.random.randint(3, 15, size=(num_day,)) # [12]*num_day #
            res = []
            for day in range(num_day):
                start = np.random.randint(0, 24-num_high_each[day])
                res.append(set(range(start, start+num_high_each[day])))
            return res
        elif self.data_ver=='syn_v5':
            num_high_each = np.random.randint(6, 12, size=(num_day,))
            res = []
            for day in range(num_day):
                start = np.random.randint(0, 24 - num_high_each[day])
                res.append(set(range(start, start + num_high_each[day])))
            return res
        else:
            selected = np.random.randint(0, 24 - 6, size=(num_day,))
            return [set(range(start, start + 6)) for start in selected]


    def dump_all(self, num_sample_each, slot=30, plot=False):
        os.makedirs('../data/{}_all'.format(fname), exist_ok=True)
        num_sample = num_sample_each * len(days_unique)
        num_day = len(days_unique)
        amps, noises = self.get_shifts(num_day, slot)
        # oracles, slot_oracles = dict(), dict()
        self.data = self.produce(days_unique, num_sample, amps, noises, slot) # list of ratios, list of dict of slot to ratio
        # self.data = self.produce(days, num_sample, tog_amps, tog_noises, slot, plot=plot)
        # self.data = final
        costs, rois, oracles, slot_oracles = self.find_oracle_each_day(slot, plot=plot)
        self.logger.info('dumping')
        self.data.to_csv('../data/{}_all/data.csv'.format(fname), index=False)
        pkl.dump(oracles, open('../data/{}_all/oracles.pkl'.format(fname), 'wb'))
        pkl.dump(slot_oracles, open('../data/{}_all/oracles_s{}.pkl'.format(fname, slot), 'wb'))
        self.logger.info('dump done', fname)

    def dump_each(self, num_sample_each, data_seeds, slot=30, plot=False, force=False):
        self.logger = self.get_logger()
        num_slot_in_day = 24*60//slot
        num_together = 1
        os.makedirs('../data/{}'.format(fname), exist_ok=True)
        num_day = len(days_unique)
        oracles, slot_oracles = dict(), dict()
        # amps, noises = self.get_shifts(num_day, slot)
        roi_high_hours = self.get_high_roi_hours(num_day)
        self.cost_planning(None, None, roi_high_hours, slot, num_sample_each)

        pids_unique = np.arange(self.num_pids)
        users_unique = np.arange(self.num_users)
        aders_unique = np.arange(self.num_aders)
        count = OrderedDict()

        costs, rois = [],[]
        for idx in range(0, len(days_unique), num_together):
            days = days_unique[idx:idx+1]
            csv_path = '../data/{}/{}.csv'.format(fname, days[0])
            num_sample = num_sample_each * len(days)
            # if self.iid:
            #     tog_amps, tog_noises = 0., 0.
            # else:
            #     tog_amps = amps[idx*num_slot_in_day:(idx+num_together)*num_slot_in_day]
            #     tog_noises = amps[idx*num_slot_in_day:(idx+num_together)*num_slot_in_day]

            already_exist = num_together==1 and os.path.exists(csv_path)
            self.set_seed(data_seeds[idx])
            if already_exist and not force:
                self.data = pd.read_csv(csv_path)
                self.logger.info('{} already exist'.format(csv_path))
            else:

                self.data = self.produce([idx], days, plot=plot)

            # self.data = final
            c,r,otmp,stmp, describes = self.find_oracle_each_day(slot, plot=plot, find=True)
            costs.extend(c)
            rois.extend(r)

            for idx,(day_no,group) in enumerate(self.data.groupby('day_no')):
                if not self.iid:
                    self.logger.info('='*50)
                    # self.logger.info('{} {} {}'.format(day_no, amps[day_no*num_slot_in_day], noises[day_no*num_slot_in_day]))

                if not already_exist or force:
                    self.logger.info('dumping {}'.format(day_no))
                    csv_path = '../data/{}/{}.csv'.format(fname, day_no)
                    group.to_csv(csv_path, index=False)
                    self.logger.info('dump done')
                count[csv_path] = group.shape[0]
                # oracles[csv_path] = otmp[idx]
                # slot_oracles[csv_path] = stmp[idx]

            del self.data

        min_ratio = 0.1#min(oracles.values())
        max_ratio = 3.9#max(oracles.values())
        meta = dict(count=sum(count.values()),
                    each_count=count,
                    min_ratio=min_ratio,
                    max_ratio=max_ratio,
                    pids=pids_unique,
                    users=users_unique,
                    aders=aders_unique,
                    oracles=oracles,
                    # slot_oracles=slot_oracles
                    )
        pkl.dump(meta, open('../data/{}/data_meta.pkl'.format(fname),'wb'))
        pkl.dump(slot_oracles, open('../data/{}/oracles_s{}.pkl'.format(fname, slot), 'wb'))
        self.logger.info('done {}'.format(fname))
        self.logger.info('plotting')
        if plot:
            folder = '../data/{}/plots'.format(fname, fname.split('.')[0])
            os.makedirs(folder, exist_ok=True)
            # subfolder = 'train' if not self.istest else 'test'
            # subfolder = osp.join(folder, subfolder)
            subfolder = folder
            os.makedirs(subfolder, exist_ok=True)
            # num_slot_in_day = 24 * (60 // 15)
            slots = np.arange(len(costs))
            # slot_costprice = pd.DataFrame(dict(slot=slots, costprice=self.costs))
            # costprice_by_slot = slot_costprice.groupby('slot').costprice.agg(np.mean)
            days = slots//num_slot_in_day
            slot_costprice = pd.DataFrame(dict(slot=slots, costprice=costs, day=days))
            max_day = max(days)
            cnt = 0
            it = 0
            while True:
                selector = slot_costprice.day.apply(lambda x: cnt <= x < min(max_day, cnt + 10))
                tmp = slot_costprice[selector]
                costprice_by_slot = tmp.groupby('slot').costprice.agg(np.mean)
                plt.title('cost_with_timeslot')
                cost_plot = sns.scatterplot(list(tmp.slot.unique()), costprice_by_slot)
                plt.savefig(osp.join(subfolder, 'cost_with_timeslot_{}.png'.format(it)))
                # matplotlib inline
                plt.show()
                it += 1
                cnt += 10
                print('cost plot {}'.format(it))
                if cnt > max_day: break
            plt.title('cost_with_timeslot')
            cost_plot = sns.lineplot(data=costs)
            plt.savefig(osp.join(subfolder, 'cost_with_slot.png'))
            # matplotlib inline
            # plt.show()
            max_lim = max([v[-1] for _,v in rois])
            for idx,(hist,values) in enumerate(rois):
                hsum = hist.sum()
                plt.clf()
                plt.title('roi_{}'.format(idx))
                # plt.xlabel('roi')
                # plt.ylabel('density')
                # plt.bar(values[:-1], hist/hsum)
                values = values[:-1]
                tmp = sns.lineplot(x='roi', y='density', data=pd.DataFrame(dict(roi=values, density=hist/hsum)))
                tmp.set(xlim=[0,max_lim])
                plt.savefig(osp.join(subfolder, 'roi_{}.png'.format(idx)))
                self.logger.info('plot {} done'.format(idx))
                # plt.clf()

    def sample_pv(self, offseted_days, original_days):
        size = self.day2nrq[offseted_days].sum()
        super(YewuSampler2, self).sample_pv(offseted_days, size)
        self.affinity_percent = 0.1
        if not self.minimal:
            self.pids = np.random.choice(
                np.arange(self.num_pids), replace=True, size=size)
            self.users = np.random.choice(
                np.arange(self.num_users), replace=True, size=size
            )
            self.ader = np.random.choice(
                np.arange(self.num_aders), replace=True, size=size
            )
            x, y = np.meshgrid(np.arange(self.num_users), np.arange(self.num_aders))
            pairs = np.hstack([x.reshape(-1, 1), y.reshape(-1, 1)])  # 300x1024, 2
            # import ipdb; ipdb.set_trace()
            indexes = np.random.choice(np.arange(self.num_users * self.num_aders),
                                       size=int(self.affinity_percent * self.num_users * self.num_aders))  # replace=False
            self.affinity_pairs = pairs[indexes]
        else:
            self.pids, self.users, self.ader, self.affinity_pairs = [None]*4
        # 某些(user,ader)会有偏高的成本
        # time
        # 按照指定的流量分布 均匀分布：binomial of
        self.days, self.hours, self.mins = [], [], []
        for ofd, od in zip(offseted_days, original_days):
            ddays = np.ones(self.day2nrq[ofd], dtype=int) * od
            self.days.append(ddays)
            for slotid in range(self.num_slot_in_day):
                hours, mins = self.sample_pv_slot(ofd, slotid)
                self.hours.append(hours)
                self.mins.append(mins)

        self.days = np.concatenate(self.days)
        self.hours = np.concatenate(self.hours)
        self.mins = np.concatenate(self.mins)

        # self.wkdays = self.days % 7

    def sample_pv_slot(self, day, slotid):
        size = self.dayslot2nrq[day*self.num_slot_in_day+slotid]

        # 某些(user,ader)会有偏高的成本
        # time
        # 按照指定的流量分布 均匀分布：binomial of
        slot_hr = slotid // self.num_slot_in_hour
        which_slot_in_hour = slotid % self.num_slot_in_hour
        hours = np.ones(size, dtype=int) * slot_hr
        mins = np.zeros(size, dtype=int)
        cnt = 0
        for mi in range(which_slot_in_hour*self.slot_width, (which_slot_in_hour+1)*self.slot_width):
            num = self.dayhrmin2nrq[day,slot_hr,mi]
            mins[cnt:cnt+num] = mi
            cnt += num
        return hours, mins

    def sample_ctr(self, size):
        # size = self.day2nrq[days].sum()
        # super(YewuSampler2, self).sample_ctr(size)
        # densities, values = self.distrs['ctr']
        # expected_ctr = (densities * values[:-1]).sum()
        # self.ctrs = np.random.choice(
        #     values[:-1], size=size, replace=True, p=densities)

        exp, mode = 0.010567, 0.007899 # self.distrs['ctr']
        # exp = mode + 0.5772 * scale
        # exp(-exp(-z)) = 0.01
        # => -exp(-z) = log0.01
        # => exp(-z) = log100
        # => -z = log(log1e5) # -2.44
        # x-mode = -2.44beta
        # know exp, want mode, such that x<0 with p<1e-5
        # mode = 2.44beta
        scale = exp / (left_factor + gamma)
        self.ctr_scale = scale
        self.ctr_mean = mode
        mode = left_factor * scale

        # scale = (exp - mode)/0.5772
        samples = np.random.gumbel(self.ctr_mean, scale=self.ctr_scale, size=size) * self.ctr_scaler
        # quant = self.gumbel_cdf_y2x(0.4)
        # print('samples ', (samples<=quant).sum()/size)
        # print('new samples', (np.random.gumbel(self.ctr_mean, self.ctr_scale, size=10000)<=quant).sum()/10000)
        ctrs = np.clip(samples, 1e-4, 1 - 1e-4)
        return ctrs


    def generate_pctr(self):
        super(YewuSampler2, self).generate_pctr()
        # noise_mean, noise_variance = self.pctr_noise_mean, self.pctr_noise_variance
        # assume high accuracy (generation conditional on true click label)
        pctrs = self.ctrs.copy()
        # 业务数据误差太大
        # import ipdb; ipdb.set_trace()
        # pctrs += np.random.randn(self.ctrs.shape[0])*noise_variance+noise_mean
        ##############

        # 如何生成noise
        ##############################
        # bias: diff/2
        # std: diff/3.
        # mean_ctr = self.ctrs.mean()
        # diff = pctrs - mean_ctr
        # bias = diff/2.
        # std = np.abs(diff/6. )
        # selector = pctrs<mean_ctr
        # tmp = np.random.randn(selector.sum())* std[selector] + bias[selector]
        # pctrs[selector] += tmp
        # # import ipdb; ipdb.set_trace()
        # selector = pctrs>mean_ctr
        # tmp = np.random.randn(selector.sum())* std[selector] + bias[selector]
        # pctrs[selector] += tmp
        ########################

        real_values = pctrs * self.pppcs  # pppc has been determined
        real_won = real_values * 1000. > self.costs
        real_lose = real_values * 1000. < self.costs
        real_rois = 1000. * self.revs / self.costs
        bad_pvs = real_rois < 1.0
        # want to elevate those bad pvs that also has small values
        need_elevation = np.logical_and(bad_pvs, real_lose)
        can_elevate = self.costs / self.pppcs / 1000. < np.quantile(pctrs, 0.75)
        # import ipdb; ipdb.set_trace()
        need_elevation = np.logical_and(can_elevate, need_elevation)  # 为了elevate需要的pctr
        # pctr_elevation = ( self.costs[need_elevation] - real_values[need_elevation] ) / self.pppcs[need_elevation] # elevate how much of current pctrs
        pctr_elevation = (self.costs - real_values * 1000.) / self.pppcs / 1000.
        idxes = np.arange(len(pctrs))[need_elevation]
        selected_idxes = np.random.choice(idxes, size=int(len(idxes) * self.elevation_percent))  # select
        tmp = pctr_elevation[selected_idxes]
        # tmp += tmp / 6. * np.abs(np.random.rand(len(tmp))) * np.sign(tmp)
        # import ipdb; ipdb.set_trace()
        pctrs[selected_idxes] += tmp
        higher = np.quantile(pctrs, 0.9)
        sel = pctrs[selected_idxes] < higher
        selected_idxes = selected_idxes[sel]
        ntmp = np.random.uniform(pctrs[selected_idxes], higher, size=len(selected_idxes))
        pctrs[selected_idxes] = ntmp
        # import ipdb; ipdb.set_trace()
        print('{} elevations'.format(len(tmp)))
        ###### degradation

        good_pvs = real_rois > 1.0
        need_degradation = np.logical_and(good_pvs, real_won)
        # import ipdb; ipdb.set_trace()
        can_degrade = self.costs / self.pppcs / 1000. > np.quantile(pctrs, 0.25)
        need_degradation = np.logical_and(can_degrade, need_degradation)
        idxes = np.arange(len(pctrs))[need_degradation]
        selected_idxes = np.random.choice(idxes, size=int(len(idxes) * self.degradation_percent))
        tmp = pctr_elevation[selected_idxes]
        # tmp -= tmp / 6. * np.abs(np.random.randn(len(tmp))) * np.sign(tmp)
        pctrs[selected_idxes] += tmp
        lower = np.quantile(pctrs, 0.1)
        sel = pctrs[selected_idxes] > lower
        selected_idxes = selected_idxes[sel]
        ntmp = np.random.uniform(lower, pctrs[selected_idxes], size=len(selected_idxes))
        pctrs[selected_idxes] = ntmp
        print('{} degradations'.format(len(tmp)))

        self.pctrs = np.clip(pctrs, 1e-4, 1 - 1e-4)
        print('predicted', pd.DataFrame(self.pctrs).describe())
        print('truth', pd.DataFrame(self.ctrs).describe())
        # import ipdb; ipdb.set_trace()

    def cost_planning(self, horizontal_shifts, vertical_shifts, roi_high_hours, slot_len, num_sample_per_day, n_periods=1):
        """
        horizontal_shifts: in one period
        vertical_shifts: positive
        n_periods: one day contains how many periods
        """
        # self.logger.info(';'.join(['amp:{},noise:{}'.format(x,y) for x,y in zip(amps, noises)]))
        self.roi_high_hours = roi_high_hours
        self.slot_width = slot_width = slot_len
        self.num_slot_in_hour = (60 // slot_width)
        self.num_slot_in_day = num_slot_in_day = self.num_slot_in_hour * 24
        self.size = size = self.num_day * num_sample_per_day
        mean, std, minvalue = 6768., 1984., 1. #self.distrs['costprice']
        # slots = self.hours * (60 // slot_width) + self.mins // slot_width + self.num_day * num_slot_in_day

        # expected_cost = (densities * values[:-1]).sum()
        if self.data_ver in ['syn_v5', 'syn_v4', 'syn_v6']:
            mean /= 2. if not raise_mean_cost else 1.5

        reverse_sin = -np.sin((np.arange(num_slot_in_day)) / num_slot_in_day * 2 * np.pi)
        high_span = np.random.randint(cost_hi_span[0], cost_hi_span[1], self.num_day)
        lower_amps = np.random.uniform(cost_amp_lo[0], cost_amp_lo[1], self.num_day)
        upper_amps = np.random.uniform(cost_amp_hi[0], cost_amp_hi[1], self.num_day)
        mean_shifts = np.random.uniform(-500, 500, self.num_day)
        cost_seq_each_day = [np.concatenate([reverse_sin[:3*num_slot_in_day // 4 - sp] * la *std,
                                            reverse_sin[3*num_slot_in_day // 4 - sp:3*num_slot_in_day // 4 + sp + 1] * ua*std,
                                            reverse_sin[3*num_slot_in_day // 4 + sp + 1:] * la*std]) + mean + ms
                            for sp, la, ua, ms in zip(high_span, lower_amps, upper_amps, mean_shifts)]
        # plt.plot(cost_seq_each_day[0])
        # plt.show()
        self.cost_mean = np.concatenate(cost_seq_each_day)
        # upper_sin = np.sin(np.arange(num_slot_in_day // 2) / num_slot_in_day * 2 * np.pi)
        # lower_sin = np.sin(np.arange(num_slot_in_day // 2, num_slot_in_day) / num_slot_in_day * 2*np.pi)
        # lower_amps = np.random.uniform(0.4,0.5, self.num_day)
        # upper_amps = np.random.uniform(0.3 if not raise_cost else 0.5, 0.6 if not raise_cost else 1.0, self.num_day)
        # values = np.concatenate([np.concatenate([mean+lower_sin*la*std,mean+upper_sin*ua*std]) for la,ua in zip(lower_amps, upper_amps)])
        # daynos = np.asarray([idx for idx in range(self.num_day) for _ in range(num_slot_in_day)])
        # # sigma = 50
        # # vertical  = random_biases[daynos]  # +np.random.normal(0, sigma, size=num_slots)
        # # horizontal = random_amps[daynos]
        # vertical = np.random.uniform(0, 500, size=self.num_day)
        # vertical_shifts = vertical[daynos]

        num_slots = num_slot_in_day * self.num_day
        # self.cost_mean = values + vertical_shifts
        roi_lo = 22.629618  # self.meta['roi']['quant'][2500:7500].mean()+10.
        roi_hi = 83.812828  # self.meta['roi']['quant'][5000:].mean()*0.3*roi_factor+10.
        roi_mean = 30. + 10.  # self.meta['rev']['quant'][5000]
        lo_amps = np.random.uniform(0, roi_mean - roi_lo, self.num_day)
        hi_amps = np.random.uniform(0, roi_hi - roi_mean, self.num_day)
        # vertical shifts
        shifted_sin = np.sin((np.arange(num_slot_in_day)-num_slot_in_day//4) / num_slot_in_day * 2 * np.pi)
        high_span = np.random.randint(roi_hi_span[0],roi_hi_span[1], self.num_day)
        roi_seq_each_day = [np.concatenate([shifted_sin[:num_slot_in_day//2-sp]*la, shifted_sin[num_slot_in_day//2-sp:num_slot_in_day//2+sp+1]*ha, shifted_sin[num_slot_in_day//2+sp+1:]*la])+roi_mean for sp,la,ha in zip(high_span, lo_amps,hi_amps)]

        # upper_sin = [np.sin((np.arange(num_slot_in_day // 2)+x) / num_slot_in_day * 2 * np.pi) for x in horizontal_shifts]
        # lower_sin = [np.sin((np.arange(num_slot_in_day // 2, num_slot_in_day)+x) / num_slot_in_day * 2 * np.pi) for x in horizontal_shifts]
        # roi_values = np.concatenate([np.concatenate([ls*lo_amp+roi_mean, us*hi_amp+roi_mean]) for ls,us in zip(lower_sin, upper_sin)])
        self.roi_mean = np.concatenate(roi_seq_each_day)
        # tmp = roi_values.reshape((-1,48))
        # for line in tmp:
        #     plt.plot(line)
        # plt.show()

        # tmp = np.sin((progress + horizontal_shifts) * n_periods * 2 * np.pi)*amplitude/3
        # cost_mean_each_day = np.asarray(self.distrs['cost_dynamics']).reshape((self.num_day,1))
        # cost_mean_each_slot = tmp.reshape((self.num_day, self.num_slot_in_day)) + cost_mean_each_day
        # self.cost_mean = cost_mean_each_slot.reshape(-1)
        # self.cost_mean = list(itertools.chain(*self.distrs['cost_dynamics']))



        # rg = np.arange(self.num_day) - self.num_day // 2
        # max_num = max(abs(rg.max()), abs(rg.min()))
        # amps = np.tile(amps.reshape((1,-1)), (1,num_slot_in_day)).reshape(-1)# ndays
        # noises = np.tile(noises.reshape((1,-1)), (1,num_slot_in_day)).reshape(-1)
        # self.cost_mean = values * amplitude * (1 + shifts) + mean + noises

        ######### normal-like
        self.cost_scales = []

        for dayno in range(self.num_day):
            for slotno in range(num_slot_in_day):
                slot_id = dayno*num_slot_in_day + slotno
                exp = self.cost_mean[slot_id]
                delta = 0
                if slot_id - 1 >= 0: delta += abs(exp - self.cost_mean[slot_id - 1])
                if slot_id + 1 < num_slots: delta += abs(self.cost_mean[slot_id + 1] - exp)
                if slot_id - 1 >= 0 and slot_id + 1 < num_slots: delta /= 2.
                scale = delta / 3.
                self.cost_scales.append(scale)

        ######## gumbel scale
        # self.cost_median = list(itertools.chain(*self.distrs['cost_mode_dynamics']))
        # self.cost_scales = (np.asarray(self.cost_mean) - np.asarray(cost_median)) / float(0.5772156649)

        self.dayslot2nrq = np.zeros(self.num_day * self.num_slot_in_day, dtype=np.int)
        self.dayhrmin2nrq = np.zeros((self.num_day, 24, 60), dtype=np.int)
        self.day2nrq = np.zeros(self.num_day, dtype=np.int)
        day_total = 0
        slotno = 0
        for day in range(self.num_day):
            if day != self.num_day-1:  # not last day

                num = np.random.binomial(size, p=1 / float(self.num_day))
                # self.days[day_total:day_total + num] = day
                prev_total = day_total
                day_total += num

            else:
                prev_total = day_total
                num = size - day_total
                # self.days[day_total:] = day

            current_day_total = num
            self.day2nrq[day] = current_day_total
            hour_total = 0
            # prev_hour_total = 0
            for hour in range(24):

                if hour != 23:  # not last hour
                    hr_num = np.random.binomial(num, p=1 / 24.)
                    # self.hours[prev_total + hour_total:prev_total + hour_total + hr_num] = hour
                    prev_hour_total = hour_total
                    hour_total += hr_num
                else:
                    prev_hour_total = hour_total
                    hr_num = current_day_total - hour_total
                    # self.hours[prev_total + hour_total:] = hour
                current_hr_total = hr_num
                min_total = 0
                slot_total = 0
                for mi in range(60):
                    if mi != 59:
                        mi_num = np.random.binomial(hr_num, p=1 / 60.)
                        # self.mins[
                        # prev_total + prev_hour_total + min_total:prev_total + prev_hour_total + min_total + mi_num] = mi
                        min_total += mi_num
                    else:
                        # self.mins[prev_total + prev_hour_total + min_total:] = mi
                        mi_num = current_hr_total - min_total

                    slot_total += mi_num
                    self.dayhrmin2nrq[day][hour][mi] = mi_num
                    if (mi + 1) % slot_len == 0:
                        # print(day, hour, mi, slotno )
                        self.dayslot2nrq[slotno] = slot_total
                        slot_total = 0
                        slotno += 1


    def sample_cost(self, days, size):

        super(YewuSampler2, self).sample_cost(size)
        # 随时间变化
        # 先确定gumbel分布均值 （cosine)
        raise_percent = self.raise_percent

        # import ipdb; ipdb.set_trace()

        self.costs = np.zeros(size)
        # 600-mode = -left_factor * scale => mode = 600+left_factor*scale
        # mode + gamma * scale = exp
        # exp = 600+ (left+gamma)*scale

        print('cost for time slots')

        sigma = 0.3
        sigma2 = sigma*sigma
        def foo(idx):
            exp = self.cost_mean[idx]
            # scale = self.cost_scales[idx]
            count = self.dayslot2nrq[idx]

            mu = np.log(exp) - 0.5*sigma2

            tmp = np.random.lognormal(mu, sigma, size=count)
            # tmp = np.random.normal(log_mean, log_scale, size=count)
            # tmp = np.exp(tmp)
            return tmp

        st = time.time()
        costs = np.concatenate(list(map(foo, [day*self.num_slot_in_day+slotno for day in days for slotno in range(self.num_slot_in_day)])))
        self.logger.info('sampling cost takes {}'.format(time.time()-st))
        self.costs = np.clip(costs, 600, np.inf)
        # for slot_id in tqdm(range(num_slots)):
        #     selector = slots == slot_id
        #     dayno = slot_id // num_slot_in_day
        #     # noise = np.random.randn()*sigma + random_biases[dayno]
        #     exp = mus[slot_id]
        #     delta = 0
        #     if slot_id-1>=0: delta += abs(exp-mus[slot_id-1])
        #     if slot_id+1<num_slots: delta += abs(mus[slot_id+1] - exp)
        #     if slot_id-1>=0 and slot_id+1<num_slots: delta /= 2.
        #     scale = delta/3.
        #     scales.append(scale)
        #     # scale = (exp - 600) / (left_factor + gamma)
        #     # mode = exp - gamma * scale
        #
        #     # tmp = np.random.gumbel(
        #     #     mode, scale=scale, size=selector.sum())
        #     tmp = np.random.normal(exp, scale, size=selector.sum())
        #
        #     # import ipdb; ipdb.set_trace()
        #     self.costs[selector] = np.clip(tmp, 600, np.inf)

        # tmp = pd.DataFrame(dict(slot=slots, costs=self.costs))
        # costprice_by_slot = tmp.groupby('slot').costs.agg(np.mean)
        # plt.title('cost_with_timeslot')
        # cost_plot = sns.lineplot(list(tmp.slot.unique()), costprice_by_slot)
        # plt.show()
        # print()
        # plt.savefig(osp.join(subfolder, 'cost_with_timeslot.png'))
        # import ipdb; ipdb.set_trace()
        #######################
        # print('cost for affinity')
        # user_ader = [str(u) + '_' + str(a) for u, a in zip(self.users, self.ader)]
        # aff = set([str(x[0]) + '_' + str(x[1]) for x in self.affinity_pairs])
        # selector = np.array([x in aff for x in user_ader])
        # self.costs[selector] *= 1 + raise_percent
        ######################
        # for pair in tqdm(self.affinity_pairs):
        #     userid, adid = pair[0],pair[1]
        #     selector = np.logical_and(self.users==userid, self.ader==adid)
        #     self.costs[selector] *= 1+raise_percent


    def sample_loose(self, size):
        # size = self.day2nrq[days].sum()
        super(YewuSampler2, self).sample_loose(size)
        if self.minimal:
            self.loose = None
            self.bidprices = None
            return
        locs = np.arange(5, 100, 5)
        numbers = np.percentile(self.costs, locs)
        indexes = np.arange(len(self.costs))
        self.loose = np.zeros(len(self.costs)).astype(bool)
        init_selector = np.ones(len(self.costs)).astype(bool)
        values = self.pppcs * self.pctrs * 1000.
        lower_for_win = self.costs / values
        uniform_ratio_upward = np.random.rand(len(self.costs)) / 2.  # [0,0.5]
        bidprice = values * (1 + uniform_ratio_upward) * lower_for_win

        for idx in range(len(locs)):  # 19 locs
            th = numbers[idx]
            selector = np.logical_and(self.costs < th, init_selector if idx == 0 else self.costs >= numbers[idx - 1])
            p_selector = np.logical_and(selector, np.random.rand(len(selector)) < locs[idx] / 100.)
            # print(locs[idx], selector.sum(), p_selector.sum())
            ind = indexes[p_selector]
            self.loose[ind] = True
            uniform_ratio_downward = np.clip(np.random.rand(p_selector.sum()), 1e-4, 1 - 1e-4) * 0.5  # [0,0.5]
            bidprice[ind] = values[ind] * (1. - uniform_ratio_downward) * lower_for_win[ind]
        self.bidprices = bidprice
        # rate = self.loose.sum() / len(self.costs)  # loose rate
        # print('loose rate:', rate)

    def sample_pid(self, days):
        # super(YewuSampler2, self).sample_pid()
        size = self.day2nrq[days].sum()
        if self.minimal: return
        self.logger.info('sample pid')
        # 分成num_spllit组pid，对应不同cost范围，组之间有交集

        init_selector = np.ones(len(self.costs)).astype(bool)
        indexes = np.arange(len(self.costs))
        num_split = 4
        split_npid = self.num_pids // num_split
        unique_pids = np.arange(self.num_pids)
        splits = [np.random.choice(unique_pids, size=split_npid, replace=False) for _ in range(num_split)]
        already_have = set(itertools.chain(*splits))
        has_not = set(unique_pids) - already_have
        splits.append(list(has_not))
        stepsize = 1. / len(splits)
        locs = np.arange(stepsize, 1. + stepsize, stepsize)
        numbers = np.quantile(self.costs, locs)
        for idx, (pids, thresh) in enumerate(zip(splits, numbers)):
            selector = np.logical_and(init_selector if idx == 0 else self.costs > numbers[idx - 1], self.costs < thresh)
            ind = indexes[selector]
            num = len(ind)
            self.pids[ind] = np.random.choice(pids, size=num, replace=True)
        # for idx,(pid, thresh) in enumerate(zip(np.arange(self.num_pids), numbers)):
        #     selector = np.logical_and(init_selector if idx==0 else self.costs>numbers[idx-1], self.costs<thresh)
        #     ind = indexes[selector]
        #     self.pids[ind] = pid

    def lognormal_sampler(self, median, mean):
        # https://brilliant.org/wiki/log-normal-distribution/
        # median = e^\mu -> mean = median * e^(sigma^2/2)
        mu = np.log(median)
        sigma_squared = np.log(mean/median) * 2.
        sigma = np.sqrt(sigma_squared)
        return lambda size:np.random.lognormal(mu, sigma, size=size)

    def lognormal_sampler2(self, mean, x):
        # lognormal:
        # https://planetcalc.com/7264/#:~:text=Log-normal%20distribution%20It%20calculates%20the%20probability%20density%20function,a%20random%20variable%20whose%20logarithm%20is%20normally%20distributed.
        # cdf: 0.5+0.5erf((lnx-mu)/(sqr(2)*scale))
        # 0.95 = 0.5 + 0.5*erf()
        #
        pass

    def gumbel_sampler2(self, x1, x2, q1, q2):
        # https://github.com/distributions-io/gumbel-cdf
        # cdf: exp(-exp(-(x-mu)/scale))
        # 满足收支平衡意味着E[PPC*CTR/cost] = 1 => 竞得部分开始积分\int_{1/(beta*CTR)} ROI = 1/CTR 约为100
        # P(PPC/cost>1/(beta*CTR)) = 0.05 通过控制0.95分位点控制beta
        t1 = np.log(-np.log(q1))
        t2 = np.log(-np.log(q2))
        alpha = t1-t2
        mean = (x1-alpha*x2)/(1-alpha)
        scale = -(x1-mean)/t1

        return lambda size: np.random.gumbel(mean, scale, size=size)

    def gumbel_cdf_y2x(self, y):
        mean, scale = self.ctr_mean, self.ctr_scale
        # find x, s.t., y = exp(-exp(-(x-mu)/scale))
        x = -np.log(-np.log(y))*scale +mean
        return x

    def gumbel_sampler(self, median, mean):
        # https://en.wikipedia.org/wiki/Gumbel_distribution
        # mean = mu+beta*gamma
        # median = mu - beta*log(log2)
        # mode = mu
        gamma = float(0.5772156649)
        assert mean>median, 'gumbel distr requires mean>median'
        # beta = (mean - median)/(gamma+np.log(np.log(2)))
        # mu = mean - beta*gamma
        mu = median
        beta = (mean - mu) / gamma
        return lambda size: np.random.gumbel(mu, beta, size=size)

    def sample_roi2(self, day, hrid, size):
        high_hours = self.roi_high_hours[day]
        is_high = hrid in high_hours
        payprob_mu_hi, payprob_mu_lo = 0.6, 0.4
        payprob_sig_hi, payprob_sig_lo = 0.1, 0.1
        pay_lo = self.meta['rev']['quant'][2500:7500].mean()*2.
        pay_hi = self.meta['rev']['quant'][5000:].mean()*2.
        if is_high:
            payprob = np.random.normal(payprob_mu_hi, payprob_sig_hi, size)
            # x1, x2 = np.random.randint(55, 80), np.random.randint(80, 95)
            # q1, q2 = 0.8, 0.9  # 1.8
            # sampler = self.gumbel_sampler2(x1, x2, q1, q2)
            # erev_div_cost = sampler(size) * 0.2
            erev_div_cost = np.random.lognormal(np.log(pay_lo), 0.5, size) * 0.1
        else:
            payprob = np.random.normal(payprob_mu_lo, payprob_sig_lo, size)
            # x1, x2 = np.random.randint(60, 80), np.random.randint(40, 60)
            # q1, q2 = 0.9, 0.6
            # sampler = self.gumbel_sampler2(x1, x2, q1, q2)
            # erev_div_cost = sampler(size) * 0.2
            erev_div_cost = np.random.lognormal(np.log(pay_hi), 0.5, size) * 0.1
            min_roi = np.percentile(erev_div_cost, 0.01)
            max_roi = np.percentile(erev_div_cost, 0.99)
        return payprob, erev_div_cost

    def sample_roi3(self, day, slotid, size):
        # payprob_mu_hi, payprob_mu_lo = 0.6, 0.4
        # payprob_sig_hi, payprob_sig_lo = 0.1, 0.1
        # pay_lo = self.meta['rev']['quant'][2500:7500].mean()*2.
        # pay_hi = self.meta['rev']['quant'][5000:].mean()*2.
        # gamma(shape, scale): expectation=shape*scale
        payprob = np.random.normal(0.45, 0.1, size)
        # erev_div_cost = np.random.lognormal(np.log(self.roi_mean[day*self.num_slot_in_day+slotid]), 0.5, size)
        shape = 5.
        exp = self.roi_mean[day*self.num_slot_in_day+slotid]
        erev_div_cost = np.random.gamma(shape, exp/shape, size)
        # plt.hist(erev_div_cost, 100, label=slotid)
        return payprob, erev_div_cost

    def sample_rev_after_clk1(self, days, size):
        # size = self.day2nrq[days].sum()
        super(YewuSampler2, self).sample_rev_after_clk1(size)
        # if 'high_roi_params' in self.distrs or 'slot_roi_params' in self.distrs:
        #     tmp = []
        #     for day in days:
        #         for hrid in range(24):
        #             sample_size = self.dayhrmin2nrq[day][hrid].sum()
        #             samples = self.sample_roi(day, hrid, sample_size)
        #             tmp.append(samples)
        #     rois = np.concatenate(tmp)
        #
        # else:
        #     rois = self.sample_roi(None, None, size)
        # erev_div_cost = payprob*pay / cost
        payprobs = []
        erois = []
        poison_ratios = []
        for day in days:
            if poison_rev:
                factor_base = np.random.uniform(rev_flunc[0], rev_flunc[1])
                npoint = np.random.choice([3,4,6])
                deviation = np.random.uniform(0, rev_dev)
                fronts = [factor_base+deviation*np.random.choice([-1.,0.,1.]) for i in range(npoint)]
                slot_factors = []
                interval_length = self.num_slot_in_day / npoint
                for i in range(npoint):
                    begin = fronts[i]
                    ed = fronts[i+1] if i<npoint-1 else factor_base
                    if begin==ed:
                        scatter = np.asarray([begin]*int(interval_length))
                    else: scatter = np.arange(begin, ed, (ed-begin)/interval_length)
                    slot_factors.append(scatter)
                slot_factors = np.concatenate(slot_factors) + np.random.normal(0,0.01, size=self.num_slot_in_day)
            for slotid in range(self.num_slot_in_day):
                sample_size = self.dayslot2nrq[day*self.num_slot_in_day+slotid]
                payprob, erev_div_cost = self.sample_roi3(day, slotid, sample_size)
                payprobs.append(payprob)
                erois.append(erev_div_cost)
                if poison_rev:
                    factor = slot_factors[slotid] #np.random.normal(factor_base, 0.05)
                    poison_ratios.append(np.ones(sample_size, np.float32) * factor)
            # for hrid in range(24):
            #     sample_size = self.dayhrmin2nrq[day][hrid].sum()
            #     payprob, erev_div_cost = self.sample_roi2(day, hrid, sample_size)
            #     payprobs.append(payprob)
            #     erois.append(erev_div_cost)
            #     if poison_rev:
            #         factor = np.random.normal(factor_base, 0.05)
            #         poison_ratios.append(np.ones(sample_size, np.float32)*factor)

        payprobs = np.concatenate(payprobs)
        erois = np.concatenate(erois)
        pays = (erois * self.costs / payprobs * 1e-3).astype(int)
        pay_or_not = np.random.rand(size)<=payprobs
        self.rev_after_clk1 = pay_or_not*pays
        self.pppcs = erois * self.costs * 1e-3
        if poison_rev:
            self.pppcs = self.pppcs * np.concatenate(poison_ratios)

        # tmp = (rois * self.costs * 1e-3).astype(int)
        # self.rev_after_clk1 = np.clip(tmp, 0, np.inf)
        # ppcpctr = rois * self.costs / 1000.
        # # import ipdb; ipdb.set_trace()
        # ppc = ppcpctr / self.ctrs
        # ppc[ppc==np.nan] = 0.
        # self.rev_after_clk1 = ppc

    def generate_pppc(self, ppcs):
        # super(YewuSampler2, self).generate_pppc()

        # noise_mean, noise_variance = self.pppc_noise_mean, self.pppc_noise_variance
        # densities, values = self.distrs['pppc_error_nonzero']
        # assume high accuracy (generation conditional on true click label)
        pppcs = ppcs
        # import ipdb; ipdb.set_trace()
        # 业务数据误差太大，先不follow
        # pppcs[pppcs!=0] *= (1.+np.random.choice(values[:-1], size=(pppcs!=0).sum(), p=densities))
        # densities, values = self.distrs['pppc_error_zero']
        # pppcs[pppcs==0] += np.random.choice(values[:-1], size=(pppcs==0).sum(), p=densities)
        ###############################
        return  np.clip(pppcs, 1e-4, np.inf)

    def generate_rev(self, ctrs, rev_after_click):
        # super(YewuSampler2, self).generate_rev()

        p = ctrs
        rands = np.random.rand(ctrs.shape[0])
        clicks = (rands < p)

        # p = self.distrs['buy']
        # rands = np.random.rand(self.ctrs.shape[0])
        # tmp = (rands < p)
        # self.has_rev = np.logical_and(tmp, self.clicks)

        revs = np.zeros(ctrs.shape[0])
        revs[clicks] = rev_after_click[clicks]
        return clicks, revs

    def get_plots(self):
        folder = 'syn_data_plots_{}'.format(fname.split('.')[0])
        os.makedirs(folder, exist_ok=True)
        subfolder = 'train' if not self.istest else 'test'
        subfolder = osp.join(folder, subfolder)
        os.makedirs(subfolder, exist_ok=True)
        num_slot_in_day = 24 * (60 // 15)
        slots = self.hours * 4 + self.mins // 15 + self.days * num_slot_in_day
        slot_costprice = pd.DataFrame(dict(slot=slots, costprice=self.costs, day=self.days))
        max_day = self.days.max()
        cnt = 0
        it = 0
        while True:
            selector = slot_costprice.day.apply(lambda x: cnt<=x<min(max_day, cnt+10))
            tmp = slot_costprice[selector]
            costprice_by_slot = tmp.groupby('slot').costprice.agg(np.mean)
            plt.title('cost_with_timeslot')
            cost_plot = sns.scatterplot(list(tmp.slot.unique()), costprice_by_slot)
            plt.savefig(osp.join(subfolder, 'cost_with_timeslot_{}.png'.format(it)))
            # matplotlib inline
            plt.show()
            it += 1
            cnt += 10
            print('cost plot {}'.format(it))
            if cnt>max_day: break
        plt.clf()
        plt.title('ctr')
        ctr_plot = sns.histplot(self.ctrs)  # cam be many zeros
        plt.savefig(osp.join(subfolder, 'ctr.png'))
        plt.show()
        plt.clf()
        plt.title('rev')
        selector = np.logical_and(self.rev_after_clk1 > 0, self.rev_after_clk1 < np.quantile(self.rev_after_clk1, 0.98))
        rev_plot = sns.histplot(
            self.rev_after_clk1[selector]
            # self.rev_after_clk1
        )
        plt.savefig(osp.join(subfolder, 'rev_extreme98_removed.png'))
        plt.show()
        plt.clf()
        plt.title('roi')
        fake_roi = self.pctrs * self.pppcs * 1000. / self.costs
        lower, upper = np.quantile(fake_roi, [0.02, 0.98])
        selector = np.logical_and(fake_roi > lower, fake_roi < upper)
        roi_plot = sns.histplot(
            fake_roi[selector]
            # fake_roi
        )
        plt.savefig(osp.join(subfolder, 'roi_extreme02_removed.png'))
        plt.show()
        plt.clf()
        plt.title('real_roi')
        r_roi = self.revs / self.costs * 1000
        r_roi = r_roi[r_roi>0]
        lower, upper = np.quantile(r_roi, [0.02, 0.98])
        selector = np.logical_and(r_roi > lower, r_roi < upper)
        roi_plot = sns.histplot(
            r_roi[selector]
            # fake_roi
        )
        # plt.savefig(osp.join(subfolder, 'roi_extreme02_removed.png'))
        plt.show()
        plt.clf()


def get_float_hist(x, granu=1000.,bins=None):
    # y = (x * granu).astype(np.int)
    if bins is None:
        y = (x * granu).astype(np.int)
        bins = y.max()-y.min()
        densities, values = np.histogram(y, density=True,
                                         bins=bins)
    else:
        y = (x * granu)
        densities, values = np.histogram(y, density=False,
                                         bins=bins)
        densities = densities / densities.sum()
    return densities, values / granu


def get_distr_from_yewu():
    df = pd.read_csv('../data/yewu-data/train.txt', header=None)
    names = ['k', 'bidid', 'time', 'wkday', 'hr', 'min', 'nick', 'pid', 'all', 'k2', 'dsp_pctr', 'ppc',  # 10
             'sessid', 'creativeid', 'pctr', 'upbidprice', 'exptime', 'costprice',
             'clk1', 'clk2', 'rev']
    df.columns = names
    dists = dict()
    # sample from histogram
    dists['costprice'] = np.histogram(df.costprice, density=True, bins=int(
        df.costprice.max() - df.costprice.min()))
    # ctr: sample from histogram
    pctr = df.pctr[df.pctr.notnull()]
    # import ipdb; ipdb.set_trace()
    # ctr是一跳点击
    # E[click rate] = \sum p(ctr)*ctr 可能和实际不符合
    # 反映了pctr和实际ctr的偏差，可以用作noise_mean
    # tmp = pctr[pctr>=0.] * 1000
    # tmp = tmp.astype(int)
    # densities, values = np.histogram(tmp, density=True, bins=tmp.max()-tmp.min())
    # values = values / 1000.
    densities, values = get_float_hist(pctr[pctr >= 0.])
    # 只有整数可以得到density积分为1

    estimated_ctr = (densities * values[:-1]).sum()
    real_ctr = df.clk1.notnull().sum() / (df.costprice > 0.).sum()  # 除以竞得总数
    dists['ctr'] = (densities, values * (real_ctr / estimated_ctr))
    diff = estimated_ctr - real_ctr
    # import ipdb; ipdb.set_trace()
    dists['pctr_noise_mean'] = diff

    rev = df[df.rev.notnull()].rev
    # 一跳后发生收入
    dists['buy'] = rev.shape[0] / df.clk1.notnull().sum()  # 购买占一跳的比例

    # sample from histogram
    # 通过业务数据中发生一跳的流量的收入分布，作为真实一跳后收入分布的经验分布
    # 所以这个经验分布应该统计发生一跳的收入
    # 另一个问题是：rev实际上是观测值，背后应该是收入分布。但是我们无法获得收入分布
    # 但因为感觉真实的收入分布中0的概率约有一半，还不能忽略收入分布中的0。所以最后决定采样收入还是按照包含0的经验分布采样，
    # 这样也不需要buyrate
    rev_clk1 = df[df.clk1.notnull()].rev.fillna(0.)  # nan rev == 0
    dists['rev'] = np.histogram(
        rev_clk1, density=True, bins=int(rev_clk1.max() - rev_clk1.min()))

    # rev_buy = df[df.rev.notnull()].rev
    # dists['rev'] = np.histogram(rev_buy, density=True, bins=int(rev.max()-rev.min()))

    # ppc = df.ppc[df.ppc.notnull()]
    # densities, values = np.histogram(ppc, density=True, bins=int(ppc.max()-ppc.min()))
    # estimated_ppc = (densities * values[:-1]).sum()
    # real_rev = rev.mean()
    # diff = estimated_ppc - real_rev
    # dists['pppc_noise_mean'] = diff

    # 因为孤立生成noise会产生一些问题，要么完全不follow 业务数据，要么换一种方法
    # 考虑到pppc和rev之间的error的分布是条件分布：error \sim p(err|rev)
    # 考虑用 error/rev 这个随机变脸来刻画 其取值天然>=-1，不会出现noise比rev还大的情况
    ppc = df.ppc[df.clk1.notnull()]
    error = ppc - rev_clk1
    error_rate_nonzero = error[rev_clk1 != 0] / rev_clk1[rev_clk1 != 0]
    error_rate_zero = error[rev_clk1 == 0]
    densities, values = get_float_hist(error_rate_nonzero)
    dists['pppc_error_nonzero'] = (densities, values)
    densities, values = get_float_hist(error_rate_zero)
    dists['pppc_error_zero'] = (densities, values)

    return dists


# 先定pv信息：id, time, nick, pid, ctr, rev_after_click
# ctr -> pctr, click; rev_after_click, click -> rev, pppc

# def synthesize_data(num_sample, sampler):
#     ids = np.arange(num_sample)
#
#     pids, users, aders, days, wkdays, hrs, mis, costs, ctrs, rev_after_buy, clicks, revs, pctrs, pppcs, loose, bidprices = sampler.generate(
#         num_sample)
#
#     df = pd.DataFrame(dict(bidid=ids.astype(np.int32),
#                            day_no=days.astype(np.int32),
#                            wkday=wkdays.astype(np.int32),
#                            hr=hrs.astype(np.int32),
#                            min=mis.astype(np.int32),
#                            nick=users.astype(np.int32),
#                            ader=aders.astype(np.int32),
#                            pid=pids.astype(np.int32),
#                            ppc=rev_after_buy.astype(np.int32),
#                            pppc=pppcs.astype(np.float32),
#                            ctr=ctrs.astype(np.float32),
#                            pctr=pctrs.astype(np.float32),
#                            click=clicks.astype(np.int32),
#                            costprice=costs.astype(np.int32),
#                            rev=revs.astype(np.int32),
#                            # loose=loose.astype(np.bool),
#                            bidprice=np.round(bidprices).astype(np.int32))
#                       )
#     # import ipdb; ipdb.set_trace()
#     # final = df.sort_values(['wkday','hr','min'])
#     # check
#     values = df.pppc * df.pctr * 1000.
#     # import ipdb; ipdb.set_trace()
#     won = values > df.costprice
#     roi = df[won].rev.sum() / (df[won].costprice.sum() / 1000.)
#     self.logger.info('truth telling roi: {}, winnum={}'.format(roi, won.sum()))
#     # import ipdb; ipdb.set_trace()
#     final = df
#     for day,tmp in final.groupby('day_no'):
#         # import ipdb; ipdb.set_trace()
#         # tmp = final[final.day_no == day]
#         print('day {} {} bids'.format(day, tmp.shape[0]))
#
#     p = 0.8
#     # df['loose'] = np.random.rand(df.shape[0])<p # p much is lost
#     # final.to_csv('../data/{}'.format(fname), mode='w', index=False)
#     print(fname)
#     # print('dump finish')
#     return final

def get_won_rev_cost(bids, costs, revs):
    wins = bids>=costs
    revsum = revs[wins].sum() * 1e3
    costsum = costs[wins].sum()
    wr = wins.sum() / len(revs)
    return revsum, costsum, wr

def compare_solution(sol1, sol2, C=1.0):
    roi1, roi2 = sol1[-1], sol2[-1]
    # 都没满足约束，选约束更接近1
    if roi1<C and roi2<C:
        if roi1>roi2: return sol1
        else: return sol2
    else:
        if roi1>=C and roi2>=C:
            rev1, rev2 = sol1[2], sol2[2]
            if rev1>rev2: return sol1
            else: return sol2
        else:
            if roi1>=C: return sol1
            return sol2


def find_step_th(th, stepsize, values, costs, revs, stop_th, old_cost, old_rev, old_wr, prt=False, C=1.0, tolerance=5):
    old_roi = old_rev/(1e-4+old_cost)
    sol = (th, old_cost, old_rev, old_wr, old_roi)
    tol_cnt = 0
    while True:
        new_th = th + stepsize
        rrev, ccost, wwr = get_won_rev_cost(values * new_th, costs, revs)
        new_roi = rrev / (ccost+1e-4)

        sol = compare_solution(sol, (new_th, ccost, rrev, wwr, new_roi))
        th = new_th
        if stepsize>0 and sol[-1]>=C and new_roi<C:
            tol_cnt += 1
            if tol_cnt==tolerance: break # find one satisfied
        if stepsize<0 and sol[-1]>=C: break
        if abs(th - stop_th) < 1e-4: # try until the stop th
            break

    if prt: print(sol)
    return sol

def get_won_rev_cost2(rois, thresh, revs, costs):
    won = rois<=thresh
    rsum = revs[won].sum()
    csum = costs[won].sum()
    return rsum, csum

def find_real_oracle(revs, costs, values, prt=False, C=1.0):
    costs *= 1e-3
    iors = costs/revs
    tt_rev, tt_cost = get_won_rev_cost2(iors, 1.0, revs, costs)
    tt_roi = tt_rev/(tt_cost+1e-4)
    step_size = 0.025
    th = 1.0
    stop_th = 5.0
    sol = (1.0, tt_cost, tt_rev, tt_roi)
    if tt_roi>=C: # lower thresh
        while True:
            new_th = th-step_size
            new_rev, new_cost = get_won_rev_cost2(iors, new_th, revs, costs)
            new_roi = new_rev/(new_cost+1e-4)
            sol = compare_solution(sol, (new_th, new_cost, new_rev, new_roi))
            th = new_th
            if sol[-1]>=C and new_roi<C:
                break
            if abs(th-step_size)<1e-4:
                break
    else: # 成本小于收益，多花钱买成本大而且收益小的
        while True:
            new_th = th+step_size
            new_rev, new_cost = get_won_rev_cost2(iors, new_th, revs, costs)
            new_roi = new_rev/(new_cost+1e-4)
            sol = compare_solution(sol, (new_th, new_cost, new_rev, new_roi))
            th = new_th
            if sol[-1]>=C:
                break
            if abs(th-stop_th)<1e-4:
                break

    return sol


def find_oracle(revs, costs, values, prt=False, C=1.0):
    th = 1.0
    tt_rev, tt_cost, wr = get_won_rev_cost(th*values, costs, revs)
    tt_roi = tt_rev / (tt_cost+1e-4)
    stop_th = 5.0

    stepsize = 0.025


    if tt_roi>1: # guess higher
        sol1 = find_step_th(th, stepsize, values, costs, revs, stop_th, tt_cost, tt_rev, wr, prt=prt, C=C)
        if sol1[-1]<C:
            sol2 = find_step_th(th, -stepsize, values, costs, revs, stepsize, tt_cost, tt_rev, wr, prt=prt, C=C)
            sol = compare_solution(sol1, sol2)
        else: sol = sol1
    elif tt_roi<1:
        sol1 = find_step_th(th, -stepsize, values, costs, revs, stepsize, tt_cost, tt_rev, wr, prt=prt, C=C)
        if sol1[-1] < C:
            sol2 = find_step_th(th, stepsize, values, costs, revs, stop_th, tt_cost, tt_rev, wr, prt=prt, C=C)
            sol = compare_solution(sol1, sol2)
        else:
            sol = sol1
    else: sol = (th, tt_cost, tt_rev, wr, tt_roi)
    # print(sol)
    # if np.isnan(sol[-1]):
    #     print('failed', sol)
    if sol[-1]<C-0.2:
        print('force 0 ratio, original is {}'.format(sol))
        sol = (0., 0, 0, 0, 0)

    return sol

# def find_oracle():
#     df = pd.read_csv('../data/{}.txt'.format(fname))
#     values = df.ppc * df.pctr
#     for th in np.arange(1.0, 4.0, 0.05):
#         selector = values * 1000 * th > df.costprice
#         ret = df.rev[selector].sum()
#         vsum = values[selector].sum()
#         cost = df.costprice[selector].sum() / 1000.
#         estimated_roi = vsum / cost
#         real_roi = ret / cost
#         win = selector.sum()
#         winrate = win / selector.shape[0]
#
#         print('thresh={} with rev={},cost={},eroi={},rroi={}, win={},winrate={}'.format(th, ret, cost, estimated_roi,
#                                                                                         real_roi, win, winrate))


def find_oracle_each_day(data=None, slot=30):
    print('finding oracle')
    if data is not None:
        df = data
    else:
        df = pd.read_csv('../data/{}'.format(fname))
    # unique_days = df.day_no.unique()
    # import ipdb; ipdb.set_trace()
    # df['day_no'] = df['wkday'].map({k: idx for idx, k in enumerate(df.wkday.unique())})
    if 'pppc' not in df.columns:
        df = df.rename(columns=dict(ppc='pppc'))

    num_slot_in_hour = 60 // slot

    df['time_slot'] = num_slot_in_hour * df.hr + df['min'] // slot
    df['value']  = df.pppc * df.pctr * 1e3
    # df['oracle'] = 0.
    # df['slot_oracle'] = 0.
    oracle_col = []
    slot_oracle_col = []
    for day, dgroup in df.groupby('day_no'):
        print(day)
        thrsh,day_roi = find_oracle(dgroup.rev, dgroup.costprice, dgroup.value, prt=True)
        oracle_col.extend([thrsh]*dgroup.shape[0])
        # print(day, thrsh, day_roi, )
        for slotid, sgroup in tqdm(dgroup.groupby('time_slot')):
            thrsh, slot_roi = find_oracle(sgroup.rev, sgroup.costprice, sgroup.value)
            # sgroup.loc[:, 'slot_oracle'] = thrsh
            slot_oracle_col.extend([thrsh]*sgroup.shape[0])

    df['oracle'] = oracle_col
    df['slot_oracle'] = slot_oracle_col


    df.to_csv('../data/{}'.format(fname), index=False)
    print('dump done')

std_factor = 1.
roi_factor = 1.0
roi_quant = 0.98


if __name__ == '__main__':
    iid = False
    plotting = False
    loading = 'each'
    # mode = 'test' #
    datatype = 'syn'
    version = '8'

    slot = 30
    prefix = datatype + '{}_v' + version

    # fname = 'syn_{}_v4'.format(mode)
    seed = 42 if gen_mode=='normal' else 43
    num_per_day = 10000000  # 5e7 * 0.2 -> 1e7 / 2.5e3
    days_unique = np.arange(start_day, start_day+num_day, 1)

    from argparse import ArgumentParser
    from runner_utils import data_seeds
    parser = ArgumentParser()
    parser.add_argument('--mode', type=int, default=0)
    args = parser.parse_args()
    # global mode,seed
    # mode = 'train'  if args.mode == 0 else 'test'
    seed += args.mode
    istest = gen_mode != 'normal'
    fname = '{}_each'.format(prefix.format('' if not iid else '_iid'))
    num_sample = num_per_day * len(days_unique)
    sampler = YewuSampler2(seed, istest, num_days=len(days_unique), iid=iid)
    # data = synthesize_data(num_sample, sampler)
    sampler.dump_each(num_per_day, data_seeds, slot=slot, plot=plotting, force=True) # force override
    # st = time.time()
    # sampler.get_plots()
    # print('plotting takes ', time.time()-st)

    # find_oracle_each_day(data=data, slot=slot)
