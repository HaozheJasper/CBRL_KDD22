import sys,os
import gym
sys.path.append(os.getcwd()+'/src')
import auction_simulator
import numpy as np
import pandas as pd
import torch
from torch.utils.tensorboard import SummaryWriter
import time
# from censoredlearning import CensoredModel
from runner_utils import make_parser, update_configs, report, prepare_and_seed, get_logger, train_or_test, main, interfaces
import logging
import itertools
import random
import pickle as pkl



class Linear(interfaces):
    def _get_model_name(self):
        return 'Linear'

    def __init__(self, cfg, test_mode=False, envname='yewu', extra_cov=0.):

        self.slot_len_in_min = eval(cfg['data']['slot_len'])
        self.num_sample_per_day = eval(cfg['data']['num_sample_per_day'])
        data_ver = cfg['data']['version']
        self.data_ver = data_ver
        diverse_constraint = 'L' in data_ver
        previous_ratio = eval(cfg['linear']['init_ratio'])
        self.final_ratio = previous_ratio  # if not given, None
        if isinstance(self.final_ratio, list):
            self.sampled_ratio = np.random.choice(self.final_ratio)
        else: self.sampled_ratio = None
        self.include_loosing = eval(cfg['data']['include_loosing'])
        self.use_syn = cfg['data']['use_syn']
        budget = eval(cfg['data']['budget'])
        if budget <= 0:
            budget_suffix = ''
        else:
            budget_suffix = '_b{}'.format(budget)
        if diverse_constraint:
            L_suffix = '_L'
        else:
            L_suffix = ''
        self.buffer = None
        self.execution = test_mode
        self.envname = envname
        self.output_dir = cfg['data'][
                              'output_dir'] + '/' + '{}_{}_{}_r({})_slot({})_wloose({})_syn({}))'.format(
            time.strftime('%y%m%d%H%M%S', time.localtime()),
            self._get_model_name(),
            self.envname,
            self.get_final_ratio(),
            eval(cfg['data']['slot_len']),
            self.include_loosing,
            self.use_syn,
        )
        os.makedirs(self.output_dir, exist_ok=True)
        self.get_logger_writer()
        if not self.execution:
            self.logger.info('output to {}'.format(self.output_dir))
            cfg.write(open(os.path.join(self.output_dir, 'config.cfg'), 'w'))
        self.test_incremental = True

        if 'yewu' in data_ver:
            # load_path = os.path.join('../data/yewu-data/v5/data_meta.pkl')
            # meta = pkl.load(open('../data/yewu-data/data_meta{}{}.pkl'.format(budget_suffix, L_suffix), 'rb'))
            # # meta = pkl.load(open(load_path, 'rb'))
            # tmp = meta['oracles']
            # dayid2oracle = {k.split(os.path.sep)[-1].split('.')[0]: v for k, v in tmp.items()}
            # fpaths = [x.split(os.path.sep)[-1].split('.')[0] for x in self.file_paths]
            # self.train_oracles = [dayid2oracle[k] for k in fpaths]
            pass
            # self.get_random_ratio()
        else:
            # load_path = os.path.join('../data', '{}_gen_meta_s{}_n{}{}_{}.pkl'.format(data_ver, self.slot_len_in_min,
            #                                                                           self.num_sample_per_day,
            #                                                                           budget_suffix, 'train'))
            # gen_meta = pkl.load(open(load_path, 'rb'))
            # k = 'rev_oracle'
            # self.train_oracles = gen_meta['day_stats'][k]['ratio']
            pass
            # self.avg_values = gen_meta['day_stats']['avg_value']
            # self.initial_value = gen_meta['day_stats']['avg_value'][0]
            # self.get_random_initial_bid()

        self.train_oracles = None
        dat = ['envname', 'actiontype', 'slotno', 'dayno', 'ratio', 'overall_roi', 'original_reward', 'normalized_reward',
               'refratio',
               'step_winrate', 'step_rev', 'step_cost', 'step_roi', 'rev', 'cost', 'win', 'nbid'] + ['original_r', 'roi',
                                                                                                     'roi-penalty',
                                                                                                     'step_rev',
                                                                                                     'rev-reward',
                                                                                                     'exp-penalty']
        if eval(cfg['rl_agent']['rewardtype']) == 3:
            dat.append('oracle_roi')
        # [original_r, roi, min(roi-1,0)*self.penalty_scale, step_rev, step_rev*self.reward_scale]
        pd.DataFrame([dat]).to_csv(os.path.join(self.output_dir, '{}_actions.csv'.format(self._get_model_name())),
                                   header=False,
                                   index=False, mode='w')
        self._step = 0

        self.results = [] # ratio index to performance

    def set_train_ratios(self, ratios):
        self.train_oracles = ratios

    def get_final_ratio(self):
        if isinstance(self.final_ratio, list):
            return self.sampled_ratio
        else: return self.final_ratio

    def get_logger_writer(self):
        self.logger = get_logger(self.output_dir)
        self.writer = SummaryWriter(self.output_dir)

    def all_over(self, *args):
        env = args[0]
        margin = 0.02
        revs = np.asarray(env.reference_all_revs['agent'])
        costs = np.asarray(env.reference_all_costs['agent'])
        L_constraints = env.all_constraint
        rois = revs/costs
        satisfaction = [roi>=L-margin for roi,L in zip(rois,L_constraints)]
        sat_ratio = sum(satisfaction)/len(satisfaction)
        # print('sat={}'.format(satisfaction))
        apr = sum([rev if sat else 0 for rev,sat in zip(revs,satisfaction)])
        self.results.append(dict(sat=sat_ratio, apr=apr))
        ratio = self.final_ratio if self.final_ratio is not None else self.train_oracles[len(self.results)-1]
        self.logger.info('ratio={}, sat={}, apr={}'.format(ratio,
                                                           sat_ratio, apr))

    def find_bid_ratio(self):
        aprs = [d['apr'] for d in self.results]
        idx = np.argmax(aprs)
        self.final_ratio = self.train_oracles[idx]
        self.logger.info('final ratio is {}, train_sat={}, train_apr={}'.format(self.final_ratio,
                                                                                self.results[idx]['sat'],
                                                                                self.results[idx]['apr']))

    def batch_act(self, obs_list): # obs maps to several specific action choices
        """
        obs: one bin for action, 100 bins for exp
        """
        it = int(obs_list[0])
        # if 'syn' in self.data_ver:
        #     current_avg_value = self.avg_values[t]
        # else:
        #     current_avg_value = obs_list[0]
        # if self.initial_bid is None:
        #     self.initial_bid = current_avg_value * self.initial_ratio * self.init_factor
        #     self.logger.info('initial bid {}'.format(self.initial_bid))
        #
        # return self.initial_bid/current_avg_value
        return self.train_oracles[it] if self.final_ratio is None else self.final_ratio

    # def get_random_initial_bid(self):
    #     rand = 10
    #     ratio = self.train_oracles[rand]
    #     self.initial_bid = self.initial_value * ratio * self.init_factor
    #     self.logger.info('initial bid {}'.format(self.initial_bid))
    #     return ratio
    #
    # def get_random_ratio(self):
    #     rand = torch.randint(len(self.train_oracles), size=()).item()
    #     ratio = self.train_oracles[rand]
    #     self.initial_ratio = ratio
    #     self.initial_bid = None
    #     self.logger.info('picking ratio no. {}: {}'.format(rand, ratio))
    #     return ratio

    def save(self, *args):
        pass

    def get_bid_ratio(self, last_ratios, action_idxes): # the first is action; others explore
        if action_idxes is None: return None
        else: return action_idxes


    def update_buffer(self, tup):
        pass

    def clear_buffer(self):
        self.buffer = None

    def learn(self, train_model): # todo: reward should be normalized within bin
        pass

    def set_execution(self, istest):
        self.execution = istest

    def dayover_logging(self):
        # self.logger.debug('loss stats: q_amp={}, qnet_loss={}'.format(self.q_amp, self.qnet_loss))
        pass

    def _get_action_space(self, *args):
        pass

    def validate_action_space(self, *args):
        pass

    def checkpointer_add_acc(self, *args):
        pass

    def check_save(self, *args):
        return False, ''

def train_before_test(sync, test_env, train_env, agent, model, test_day_unit, train_max_days, exploration_num, C, window_size, **kwargs):
    agent.set_train_ratios(train_env.reader.oracle_ratios)
    agent.set_train_ratios(list(np.arange(1.,1.5,0.05)))
    if agent.final_ratio is None:
        for it in range(min(15,len(agent.train_oracles))): # len(agent.train_oracles)
            train_or_test(train_env, agent, window_size, exploration_num, C, istest=False, need_exploration=False, epoch_it=it)
            train_env.set_step(0)
            train_env.reset_traversal()
        agent.find_bid_ratio()
    train_or_test(test_env, agent, window_size, exploration_num, C, istest=True, need_exploration=False)

def make_agent(cfg, test, envname):
    agent = Linear(cfg, envname=envname, test_mode=test)
    return agent

if __name__ == '__main__':
    args = make_parser()
    main(args, make_agent, train_before_test)