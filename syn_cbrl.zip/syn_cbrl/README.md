
## step 1: generate csv bidding logs
`python/synthesize.py`: set the following parameters and run.
+ `gen_mode`: 'normal' or 'ood', implies two different data distribution. 
Hypers of the two distributions are set in line 20~42.
+ `start_day, num_day`: controls the day range of each data distribution. 
Logs are generated in day-wise manner, with path `data/syn_<version>_each/<number>.csv`. 
Each day is assumed a distinct auction environment.
Different `gen_mode` should not use overlapped day range. 
+ `version`: version of dataset. Logs are saved in `data/syn_<version>_each`.

This step generates a data folder `data/syn_<version>_each` with csv bidding logs in it. 

## step 2: generate data meta information and optimal policies. 
`pip install pulp`: installs a package for integer programming.
`python/make_syn.py`: set the data folder `folder` and then run. 

This step generates a meta file `data_meta_v1_f.pkl` in the data folder, and 
a few other meta files. 

## step 3: run algorithms with log-based simulation
under the `python/` folder: `bash scripts/cbrl_ep.sh`

